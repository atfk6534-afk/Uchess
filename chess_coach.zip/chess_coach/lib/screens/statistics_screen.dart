import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import '../services/game_repository.dart';

class StatisticsScreen extends StatelessWidget {
  final GameRepository repository;
  final String username;

  const StatisticsScreen({super.key, required this.repository, this.username = ''});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: repository,
      builder: (context, _) {
        final analyzed = repository.games.where((g) => g.isAnalyzed).toList();
        final stats = _computeStats(repository.games, analyzed, username);

        return Scaffold(
          appBar: AppBar(title: const Text('Statistics')),
          body: repository.games.isEmpty
              ? const Center(child: Text('Import and analyze some games to see stats.'))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Row(
                      children: [
                        _StatCard(label: 'Games', value: '${repository.games.length}'),
                        _StatCard(label: 'Analyzed', value: '${analyzed.length}'),
                        _StatCard(label: 'W-L-D', value: stats.record),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _StatCard(
                            label: 'Avg accuracy',
                            value: stats.avgAccuracy != null
                                ? '${stats.avgAccuracy!.toStringAsFixed(1)}%'
                                : '—'),
                        _StatCard(label: 'Avg ACPL', value: stats.avgAcpl?.toStringAsFixed(0) ?? '—'),
                        _StatCard(label: 'Blunders', value: '${stats.totalBlunders}'),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text('Mistake breakdown', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 180,
                      child: analyzed.isEmpty
                          ? const Center(child: Text('No analyzed games yet.'))
                          : BarChart(
                              BarChartData(
                                barGroups: [
                                  _bar(0, stats.blunders.toDouble(), Colors.red),
                                  _bar(1, stats.mistakes.toDouble(), Colors.orange),
                                  _bar(2, stats.inaccuracies.toDouble(), Colors.amber),
                                  _bar(3, stats.missedWins.toDouble(), Colors.deepPurple),
                                ],
                                titlesData: FlTitlesData(
                                  bottomTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      getTitlesWidget: (value, meta) {
                                        const labels = ['Blunders', 'Mistakes', 'Inaccuracies', 'Missed wins'];
                                        final i = value.toInt();
                                        return Padding(
                                          padding: const EdgeInsets.only(top: 6),
                                          child: Text(i < labels.length ? labels[i] : '',
                                              style: const TextStyle(fontSize: 10)),
                                        );
                                      },
                                    ),
                                  ),
                                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true)),
                                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                ),
                                gridData: const FlGridData(show: false),
                                borderData: FlBorderData(show: false),
                              ),
                            ),
                    ),
                    const SizedBox(height: 24),
                    Text('Most played openings', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    ...stats.topOpenings.map((e) => ListTile(
                          dense: true,
                          title: Text(e.key),
                          trailing: Text('${e.value}'),
                        )),
                  ],
                ),
        );
      },
    );
  }

  BarChartGroupData _bar(int x, double y, Color color) {
    return BarChartGroupData(x: x, barRods: [BarChartRodData(toY: y, color: color, width: 22)]);
  }

  _Stats _computeStats(List<ChessGame> all, List<ChessGame> analyzed, String username) {
    var wins = 0, losses = 0, draws = 0;
    for (final g in all) {
      if (g.result == '1/2-1/2') {
        draws++;
      } else if (username.isNotEmpty) {
        final isWhite = g.white.toLowerCase() == username.toLowerCase();
        final userWon = (isWhite && g.result == '1-0') || (!isWhite && g.result == '0-1');
        if (userWon) {
          wins++;
        } else {
          losses++;
        }
      }
    }

    var blunders = 0, mistakes = 0, inaccuracies = 0, missedWins = 0;
    double accSum = 0;
    var accCount = 0;
    double acplSum = 0;
    var acplCount = 0;

    for (final g in analyzed) {
      final isWhite = g.white.toLowerCase() == username.toLowerCase();
      final userMoves = g.analysis!
          .where((m) => (m.fenBefore.split(' ')[1] == 'w') == (username.isEmpty ? true : isWhite))
          .toList();

      for (final m in userMoves) {
        switch (m.classification) {
          case MoveClassification.blunder:
            blunders++;
            break;
          case MoveClassification.mistake:
            mistakes++;
            break;
          case MoveClassification.inaccuracy:
            inaccuracies++;
            break;
          case MoveClassification.missedWin:
            missedWins++;
            break;
          default:
            break;
        }
      }

      if (userMoves.isNotEmpty) {
        final acpl = userMoves.map((m) => m.evalLossForMover.clamp(0, 1000)).reduce((a, b) => a + b) /
            userMoves.length;
        acplSum += acpl;
        acplCount++;
      }

      accSum += g.accuracyFor(username.isEmpty ? true : isWhite);
      accCount++;
    }

    final openingCounts = <String, int>{};
    for (final g in all) {
      final name = g.opening ?? 'Unknown';
      openingCounts[name] = (openingCounts[name] ?? 0) + 1;
    }
    final topOpenings = openingCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return _Stats(
      record: '$wins-$losses-$draws',
      avgAccuracy: accCount > 0 ? accSum / accCount : null,
      avgAcpl: acplCount > 0 ? acplSum / acplCount : null,
      totalBlunders: blunders,
      blunders: blunders,
      mistakes: mistakes,
      inaccuracies: inaccuracies,
      missedWins: missedWins,
      topOpenings: topOpenings.take(5).toList(),
    );
  }
}

class _Stats {
  final String record;
  final double? avgAccuracy;
  final double? avgAcpl;
  final int totalBlunders;
  final int blunders, mistakes, inaccuracies, missedWins;
  final List<MapEntry<String, int>> topOpenings;

  _Stats({
    required this.record,
    required this.avgAccuracy,
    required this.avgAcpl,
    required this.totalBlunders,
    required this.blunders,
    required this.mistakes,
    required this.inaccuracies,
    required this.missedWins,
    required this.topOpenings,
  });
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  const _StatCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(
            children: [
              Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
