import 'package:flutter/material.dart';

import '../models/chess_game.dart';
import '../services/game_repository.dart';
import 'game_viewer_screen.dart';

enum GameFilter { all, wins, losses, draws, rapid, blitz, bullet, classical, unanalyzed, mostMistakes }

enum GameSort { newest, oldest, rating, mistakes, length }

class GamesLibraryScreen extends StatefulWidget {
  final GameRepository repository;
  final String currentUsername; // used to determine win/loss from the user's side

  const GamesLibraryScreen({
    super.key,
    required this.repository,
    this.currentUsername = '',
  });

  @override
  State<GamesLibraryScreen> createState() => _GamesLibraryScreenState();
}

class _GamesLibraryScreenState extends State<GamesLibraryScreen> {
  GameFilter _filter = GameFilter.all;
  GameSort _sort = GameSort.newest;
  String _query = '';

  bool _matchesFilter(ChessGame g) {
    switch (_filter) {
      case GameFilter.all:
        return true;
      case GameFilter.wins:
        return _isUserResult(g, '1-0-w') || _isUserResult(g, '0-1-b');
      case GameFilter.losses:
        return _isUserResult(g, '0-1-w') || _isUserResult(g, '1-0-b');
      case GameFilter.draws:
        return g.result == '1/2-1/2';
      case GameFilter.rapid:
        return g.timeControlCategory == TimeControlCategory.rapid;
      case GameFilter.blitz:
        return g.timeControlCategory == TimeControlCategory.blitz;
      case GameFilter.bullet:
        return g.timeControlCategory == TimeControlCategory.bullet;
      case GameFilter.classical:
        return g.timeControlCategory == TimeControlCategory.classical;
      case GameFilter.unanalyzed:
        return !g.isAnalyzed;
      case GameFilter.mostMistakes:
        return g.isAnalyzed &&
            g.analysis!.where((m) =>
                m.classification.name == 'mistake' || m.classification.name == 'blunder').length >=
                2;
    }
  }

  bool _isUserResult(ChessGame g, String code) {
    if (widget.currentUsername.isEmpty) return false;
    final isWhite = g.white.toLowerCase() == widget.currentUsername.toLowerCase();
    final side = isWhite ? 'w' : 'b';
    final result = code.split('-').take(2).join('-');
    return g.result == result && code.endsWith(side);
  }

  bool _matchesQuery(ChessGame g) {
    if (_query.isEmpty) return true;
    final q = _query.toLowerCase();
    return g.white.toLowerCase().contains(q) ||
        g.black.toLowerCase().contains(q) ||
        (g.opening ?? '').toLowerCase().contains(q);
  }

  List<ChessGame> _sorted(List<ChessGame> games) {
    final list = [...games];
    switch (_sort) {
      case GameSort.newest:
        list.sort((a, b) => (b.date ?? DateTime(0)).compareTo(a.date ?? DateTime(0)));
        break;
      case GameSort.oldest:
        list.sort((a, b) => (a.date ?? DateTime(0)).compareTo(b.date ?? DateTime(0)));
        break;
      case GameSort.rating:
        list.sort((a, b) => (b.whiteRating ?? 0).compareTo(a.whiteRating ?? 0));
        break;
      case GameSort.mistakes:
        list.sort((a, b) => _mistakeCount(b).compareTo(_mistakeCount(a)));
        break;
      case GameSort.length:
        list.sort((a, b) => b.moveCount.compareTo(a.moveCount));
        break;
    }
    return list;
  }

  int _mistakeCount(ChessGame g) {
    if (!g.isAnalyzed) return -1;
    return g.analysis!
        .where((m) => m.classification.name == 'mistake' || m.classification.name == 'blunder')
        .length;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.repository,
      builder: (context, _) {
        final visible =
            _sorted(widget.repository.games.where(_matchesFilter).where(_matchesQuery).toList());

        return Scaffold(
          appBar: AppBar(
            title: const Text('Games'),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(48),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search opponent or opening',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
            ),
            actions: [
              PopupMenuButton<GameSort>(
                icon: const Icon(Icons.sort),
                onSelected: (v) => setState(() => _sort = v),
                itemBuilder: (context) => GameSort.values
                    .map((s) => PopupMenuItem(value: s, child: Text(s.name)))
                    .toList(),
              ),
            ],
          ),
          body: Column(
            children: [
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  children: GameFilter.values.map((f) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
                      child: ChoiceChip(
                        label: Text(f.name),
                        selected: _filter == f,
                        onSelected: (_) => setState(() => _filter = f),
                      ),
                    );
                  }).toList(),
                ),
              ),
              if (widget.repository.isLoading) const LinearProgressIndicator(),
              Expanded(
                child: visible.isEmpty
                    ? const Center(child: Text('No games match this filter yet.'))
                    : ListView.builder(
                        itemCount: visible.length,
                        itemBuilder: (context, i) => _GameCard(game: visible[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _GameCard extends StatelessWidget {
  final ChessGame game;
  const _GameCard({required this.game});

  @override
  Widget build(BuildContext context) {
    final mistakes = game.isAnalyzed
        ? game.analysis!
            .where((m) => m.classification.name == 'mistake' || m.classification.name == 'blunder')
            .length
        : null;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => GameViewerScreen(game: game)),
        ),
        title: Text('${game.white} vs ${game.black}'),
        subtitle: Text(
          [
            game.opening ?? 'Unknown opening',
            if (game.date != null)
              '${game.date!.year}-${game.date!.month.toString().padLeft(2, '0')}-${game.date!.day.toString().padLeft(2, '0')}',
            game.timeControlCategory.name,
          ].join(' · '),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(game.result, style: const TextStyle(fontWeight: FontWeight.bold)),
            if (mistakes != null)
              Text('$mistakes mistakes', style: const TextStyle(fontSize: 11, color: Colors.grey))
            else
              const Text('Not analyzed', style: TextStyle(fontSize: 11, color: Colors.orange)),
          ],
        ),
      ),
    );
  }
}
