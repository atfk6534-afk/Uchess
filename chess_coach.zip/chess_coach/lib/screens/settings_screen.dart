import 'package:flutter/material.dart';

import '../services/analysis_source.dart';
import '../services/app_config.dart';
import '../services/game_repository.dart';
import '../services/lichess_service.dart';
import '../theme/board_theme.dart';

/// Holds user-adjustable settings in memory for Phase 1/2. Wiring this to
/// persisted storage (sqflite/shared prefs) is a small follow-up once the
/// local database layer lands — the shape here won't need to change.
class AppSettings extends ChangeNotifier {
  AnalysisMode analysisMode = AnalysisMode.auto;
  int engineDepth = 16;
  int multiPv = 1;
  BoardTheme boardTheme = BoardTheme.emerald;
  bool analyzeAutomaticallyAfterImport = false;

  void update(void Function() fn) {
    fn();
    notifyListeners();
  }
}

class SettingsScreen extends StatefulWidget {
  final AppSettings settings;
  final GameRepository? repository;
  const SettingsScreen({super.key, required this.settings, this.repository});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _lichess = LichessService();
  bool _lichessConnected = false;

  @override
  void initState() {
    super.initState();
    _refreshLichessStatus();
  }

  Future<void> _refreshLichessStatus() async {
    final connected = await _lichess.isConnected;
    if (mounted) setState(() => _lichessConnected = connected);
  }

  Future<void> _showChessComDialog(BuildContext context) async {
    final controller = TextEditingController();
    final username = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Connect Chess.com'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Chess.com username'),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Sync'),
          ),
        ],
      ),
    );
    if (username == null || username.isEmpty || widget.repository == null) return;

    try {
      final added = await widget.repository!.syncChessCom(username);
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Synced $added new game(s) from Chess.com.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          const _SectionHeader('Analysis'),
          RadioListTile<AnalysisMode>(
            title: const Text('Auto (cloud first, local fallback)'),
            value: AnalysisMode.auto,
            groupValue: s.analysisMode,
            onChanged: (v) => setState(() => s.update(() => s.analysisMode = v!)),
          ),
          RadioListTile<AnalysisMode>(
            title: const Text('Cloud only'),
            subtitle: AppConfig.hasCloudServerConfigured
                ? null
                : const Text('No server configured — see README', style: TextStyle(color: Colors.orange)),
            value: AnalysisMode.cloud,
            groupValue: s.analysisMode,
            onChanged: (v) => setState(() => s.update(() => s.analysisMode = v!)),
          ),
          RadioListTile<AnalysisMode>(
            title: const Text('Offline (local Stockfish only)'),
            value: AnalysisMode.offline,
            groupValue: s.analysisMode,
            onChanged: (v) => setState(() => s.update(() => s.analysisMode = v!)),
          ),
          ListTile(
            title: const Text('Engine depth'),
            subtitle: Slider(
              value: s.engineDepth.toDouble(),
              min: 8,
              max: 22,
              divisions: 14,
              label: '${s.engineDepth}',
              onChanged: (v) => setState(() => s.update(() => s.engineDepth = v.round())),
            ),
          ),
          ListTile(
            title: const Text('MultiPV (number of engine lines)'),
            subtitle: Slider(
              value: s.multiPv.toDouble(),
              min: 1,
              max: 5,
              divisions: 4,
              label: '${s.multiPv}',
              onChanged: (v) => setState(() => s.update(() => s.multiPv = v.round())),
            ),
          ),
          SwitchListTile(
            title: const Text('Analyze automatically after import'),
            value: s.analyzeAutomaticallyAfterImport,
            onChanged: (v) =>
                setState(() => s.update(() => s.analyzeAutomaticallyAfterImport = v)),
          ),
          const _SectionHeader('Board'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 10,
              children: BoardTheme.all.map((theme) {
                final selected = theme.name == s.boardTheme.name;
                return ChoiceChip(
                  label: Text(theme.name),
                  selected: selected,
                  onSelected: (_) => setState(() => s.update(() => s.boardTheme = theme)),
                );
              }).toList(),
            ),
          ),
          const _SectionHeader('Accounts'),
          ListTile(
            leading: const Icon(Icons.link),
            title: const Text('Lichess'),
            subtitle: Text(_lichessConnected
                ? 'Connected'
                : AppConfig.hasLichessConfigured
                    ? 'Not connected'
                    : 'Requires one-time setup — see README'),
            trailing: FilledButton(
              onPressed: !AppConfig.hasLichessConfigured
                  ? null
                  : () async {
                      if (_lichessConnected) {
                        await _lichess.disconnect();
                      } else {
                        try {
                          await _lichess.startAuth();
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text('$e')));
                          }
                        }
                      }
                      _refreshLichessStatus();
                    },
              child: Text(_lichessConnected ? 'Disconnect' : 'Connect'),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Chess.com'),
            subtitle: const Text('Just enter your username — no password, no login needed'),
            trailing: FilledButton(
              onPressed: () => _showChessComDialog(context),
              child: const Text('Sync'),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
      child: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }
}
