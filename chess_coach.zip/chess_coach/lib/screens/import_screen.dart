import 'package:flutter/material.dart';

import '../services/pgn_parser.dart';
import 'game_viewer_screen.dart';

class ImportScreen extends StatefulWidget {
  const ImportScreen({super.key});

  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  final _controller = TextEditingController();
  String? _error;

  void _importPgn() {
    setState(() => _error = null);
    try {
      final games = PgnParser.parseMultiple(_controller.text);
      if (games.length == 1) {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => GameViewerScreen(game: games.first)),
        );
      } else {
        Navigator.of(context).pop(games);
      }
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Import Game')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Paste PGN text below. You can paste a single game or a whole '
              'PGN file with multiple games.',
            ),
            const SizedBox(height: 12),
            Expanded(
              child: TextField(
                controller: _controller,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: '[Event "..."]\n[White "..."]\n1. e4 e5 2. Nf3 ...',
                ),
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _importPgn,
              icon: const Icon(Icons.download),
              label: const Text('Import'),
            ),
          ],
        ),
      ),
    );
  }
}
