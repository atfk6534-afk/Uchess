import 'package:flutter/material.dart';

import '../services/game_repository.dart';
import 'games_library_screen.dart';
import 'import_screen.dart';
import 'settings_screen.dart';
import 'statistics_screen.dart';
import 'training_screen.dart';

class HomeShell extends StatefulWidget {
  final GameRepository repository;
  final AppSettings settings;

  const HomeShell({super.key, required this.repository, required this.settings});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _HomeTab(repository: widget.repository),
      GamesLibraryScreen(repository: widget.repository),
      StatisticsScreen(repository: widget.repository),
      SettingsScreen(settings: widget.settings, repository: widget.repository),
    ];

    return Scaffold(
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.list_alt_outlined), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), label: 'Stats'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  final GameRepository repository;
  const _HomeTab({required this.repository});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: repository,
      builder: (context, _) {
        final recentGames = repository.games.take(5).toList();
        return Scaffold(
          appBar: AppBar(title: const Text('Chess Coach')),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text('Good to see you.',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text('${repository.games.length} games in your library.',
                  style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 20),
              _ActionCard(
                icon: Icons.file_download_outlined,
                title: 'Import PGN',
                subtitle: 'Paste PGN text or a saved game file',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ImportScreen()),
                ),
              ),
              const SizedBox(height: 10),
              _ActionCard(
                icon: Icons.psychology_alt_outlined,
                title: 'Train my mistakes',
                subtitle: 'Practice the exact spots you went wrong',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) =>
                        TrainingScreen(repository: repository, kind: TrainingKind.mistakes),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _ActionCard(
                icon: Icons.warning_amber_outlined,
                title: 'Blunder trainer',
                subtitle: 'Practice your biggest mistakes',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) =>
                        TrainingScreen(repository: repository, kind: TrainingKind.blunders),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              if (recentGames.isNotEmpty) ...[
                Text('Recent games', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                ...recentGames.map((g) => Card(
                      child: ListTile(
                        title: Text('${g.white} vs ${g.black}'),
                        subtitle: Text(g.opening ?? 'Unknown opening'),
                        trailing: Text(g.result),
                      ),
                    )),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Theme.of(context).colorScheme.surfaceContainerHigh,
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Icon(icon, size: 32),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        onTap: onTap,
      ),
    );
  }
}
