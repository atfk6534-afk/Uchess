import 'package:flutter/material.dart';

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import '../services/board_controller.dart';
import '../services/game_repository.dart';
import '../theme/board_theme.dart';
import '../widgets/chess_board.dart';

enum TrainingKind { mistakes, blunders, missedWins }

class _TrainingItem {
  final ChessGame game;
  final MoveAnalysis move;
  _TrainingItem(this.game, this.move);
}

class TrainingScreen extends StatefulWidget {
  final GameRepository repository;
  final TrainingKind kind;

  const TrainingScreen({super.key, required this.repository, required this.kind});

  @override
  State<TrainingScreen> createState() => _TrainingScreenState();
}

class _TrainingScreenState extends State<TrainingScreen> {
  late List<_TrainingItem> _items;
  int _index = 0;
  final BoardController _board = BoardController();
  String? _feedback;
  bool _answered = false;

  @override
  void initState() {
    super.initState();
    _items = _collectItems();
    if (_items.isNotEmpty) _loadCurrent();
  }

  List<_TrainingItem> _collectItems() {
    final target = switch (widget.kind) {
      TrainingKind.mistakes => MoveClassification.mistake,
      TrainingKind.blunders => MoveClassification.blunder,
      TrainingKind.missedWins => MoveClassification.missedWin,
    };
    final items = <_TrainingItem>[];
    for (final g in widget.repository.games.where((g) => g.isAnalyzed)) {
      for (final m in g.analysis!) {
        if (m.classification == target) {
          items.add(_TrainingItem(g, m));
        }
      }
    }
    items.shuffle();
    return items;
  }

  void _loadCurrent() {
    final item = _items[_index];
    _board.loadFen(item.move.fenBefore);
    _answered = false;
    _feedback = null;
  }

  void _onSquareTap(Square square) {
    if (_answered) return;
    final san = _board.handleTap(square);
    if (san == null) {
      setState(() {}); // just a selection change
      return;
    }

    final item = _items[_index];
    final correct = san == item.move.bestMoveSan;
    setState(() {
      _answered = true;
      _feedback = correct
          ? 'Correct! ${item.move.bestMoveSan} was the best move.'
          : 'Not quite — you played $san. The best move was ${item.move.bestMoveSan}.\n\n${item.move.explanation ?? ''}';
    });
  }

  void _next() {
    setState(() {
      _index = (_index + 1) % _items.length;
      _loadCurrent();
    });
  }

  @override
  Widget build(BuildContext context) {
    final title = switch (widget.kind) {
      TrainingKind.mistakes => 'Mistake Trainer',
      TrainingKind.blunders => 'Blunder Trainer',
      TrainingKind.missedWins => 'Missed Wins Trainer',
    };

    if (_items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'No positions here yet — analyze a few games first and this trainer '
              'will fill up with your own mistakes to practice.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final item = _items[_index];

    return Scaffold(
      appBar: AppBar(title: Text('$title (${_index + 1}/${_items.length})')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Text(
                '${item.game.white} vs ${item.game.black} — find the best move for '
                '${item.move.fenBefore.split(' ')[1] == 'w' ? 'White' : 'Black'}',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              AnimatedBuilder(
                animation: _board,
                builder: (context, _) => AspectRatio(
                  aspectRatio: 1,
                  child: ChessBoardWidget(
                    board: _board.boardGrid,
                    theme: BoardTheme.emerald,
                    selected: _board.selected,
                    legalTargets: _board.legalTargets,
                    kingInCheck: _board.kingInCheck,
                    onSquareTap: _onSquareTap,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (_feedback != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHigh,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(_feedback!),
                ),
              const SizedBox(height: 12),
              if (_answered)
                FilledButton(onPressed: _next, child: const Text('Next position')),
            ],
          ),
        ),
      ),
    );
  }
}
