import 'package:flutter/material.dart';

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import '../services/analysis_engine.dart';
import '../services/board_controller.dart';
import '../services/pgn_parser.dart';
import '../services/stockfish_service.dart';
import '../theme/board_theme.dart';
import '../widgets/chess_board.dart';
import '../widgets/eval_graph.dart';
import '../widgets/evaluation_bar.dart';

class GameViewerScreen extends StatefulWidget {
  final ChessGame game;
  const GameViewerScreen({super.key, required this.game});

  @override
  State<GameViewerScreen> createState() => _GameViewerScreenState();
}

class _GameViewerScreenState extends State<GameViewerScreen> {
  late final BoardController _board;
  late final List<String> _fenSequence;
  late final List<String> _sanMoves;
  int _currentPly = 0;

  ChessGame? _analyzedGame;
  int _analyzedCount = 0;
  String? _analysisError;
  AnalysisEngine? _analysisEngine;

  // Talks to the single app-wide Stockfish instance — never constructs
  // its own engine, which is what previously caused
  // "Bad state: Multiple instances are not supported, yet." on the
  // second analysis of the app's lifetime.
  final StockfishService _engine = StockfishService.instance;

  @override
  void initState() {
    super.initState();
    _board = BoardController();
    _fenSequence = PgnParser.fenSequence(widget.game.pgn);
    _sanMoves = PgnParser.sanMoves(widget.game.pgn);
    _analyzedGame = widget.game.isAnalyzed ? widget.game : null;
    _board.loadFen(_fenSequence.first);
  }

  // Deliberately no dispose() call on the engine here — the singleton is
  // shared app-wide and stays alive for the whole process lifetime. See
  // StockfishService's doc comment for why disposing/recreating it is
  // exactly the bug this screen used to have.

  void _goToPly(int ply) {
    if (ply < 0 || ply >= _fenSequence.length) return;
    setState(() {
      _currentPly = ply;
      _board.loadFen(_fenSequence[ply]);
    });
  }

  Future<void> _startAnalysis() async {
    if (_engine.isAnalyzing) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('التحليل جارٍ بالفعل')),
      );
      return;
    }

    setState(() {
      _analysisError = null;
      _analyzedCount = 0;
    });

    try {
      await _engine.init();
      final analysisEngine = AnalysisEngine(_engine);
      _analysisEngine = analysisEngine;

      final results = await analysisEngine.analyzeGame(
        widget.game,
        depth: 16,
        onProgress: (done, total) {
          if (mounted) setState(() => _analyzedCount = done);
        },
      );

      if (mounted) {
        setState(() {
          _analyzedGame = widget.game.copyWith(
            analysis: results,
            analyzedAt: DateTime.now(),
          );
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _analysisError = 'فشل التحليل: تعذر الوصول إلى محرك التحليل. حاول مرة أخرى.';
        });
      }
    }
  }

  void _cancelAnalysis() {
    _analysisEngine?.cancel();
    _engine.stopAnalysis();
  }

  MoveAnalysis? get _currentMoveAnalysis {
    if (_analyzedGame?.analysis == null || _currentPly == 0) return null;
    final idx = _currentPly - 1;
    if (idx < 0 || idx >= _analyzedGame!.analysis!.length) return null;
    return _analyzedGame!.analysis![idx];
  }

  @override
  Widget build(BuildContext context) {
    final analysis = _analyzedGame?.analysis;
    final currentMove = _currentMoveAnalysis;
    final isAnalyzing = _engine.isAnalyzing;
    final screenWidth = MediaQuery.of(context).size.width;
    final boardSize = screenWidth - 24 - 40; // leave room for the eval bar

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.game.white} ضد ${widget.game.black}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flip),
            tooltip: 'قلب الرقعة',
            onPressed: () => setState(() => _board.toggleFlip()),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _GameHeader(game: widget.game),
            if (analysis != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: EvalGraph(
                  moves: analysis,
                  currentPly: _currentPly,
                  onTapPly: _goToPly,
                ),
              ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    EvaluationBar(
                      evaluation: currentMove?.evalAfter,
                      height: boardSize,
                      width: 22,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: AnimatedBuilder(
                        animation: _board,
                        builder: (context, _) {
                          return AspectRatio(
                            aspectRatio: 1,
                            child: ChessBoardWidget(
                              board: _board.boardGrid,
                              flipped: _board.flipped,
                              theme: BoardTheme.emerald,
                              kingInCheck: _board.kingInCheck,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _EvalAndNavBar(
              evalLabel: currentMove?.evalAfter.display ??
                  (_currentPly == 0 ? '+0.00' : '—'),
              bestMove: currentMove?.bestMoveSan,
              classification: currentMove?.classification,
              ply: _currentPly,
              totalPlies: _fenSequence.length - 1,
              onFirst: () => _goToPly(0),
              onPrev: () => _goToPly(_currentPly - 1),
              onNext: () => _goToPly(_currentPly + 1),
              onLast: () => _goToPly(_fenSequence.length - 1),
            ),
            if (_analysisError != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Text(
                  _analysisError!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 13),
                ),
              ),
            if (!widget.game.isAnalyzed && _analyzedGame == null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: isAnalyzing
                    ? Column(
                        children: [
                          LinearProgressIndicator(
                            value: _sanMoves.isEmpty
                                ? null
                                : _analyzedCount / _sanMoves.length,
                          ),
                          const SizedBox(height: 4),
                          Text('جارٍ التحليل $_analyzedCount / ${_sanMoves.length}',
                              style: const TextStyle(fontSize: 12)),
                          TextButton(
                            onPressed: _cancelAnalysis,
                            child: const Text('إيقاف التحليل'),
                          ),
                        ],
                      )
                    : SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _startAnalysis,
                          icon: const Icon(Icons.auto_awesome),
                          label: const Text('تحليل باستخدام Stockfish'),
                        ),
                      ),
              ),
            SizedBox(
              height: 56,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _sanMoves.length,
                itemBuilder: (context, i) {
                  final moveNum = (i ~/ 2) + 1;
                  final isWhiteMove = i % 2 == 0;
                  final label = isWhiteMove ? '$moveNum. ${_sanMoves[i]}' : _sanMoves[i];
                  final selected = _currentPly == i + 1;
                  final ma = analysis != null && i < analysis.length ? analysis[i] : null;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                    child: ChoiceChip(
                      label: Text(
                        '$label${ma != null ? ma.classification.symbol : ''}',
                        textDirection: TextDirection.ltr,
                      ),
                      selected: selected,
                      onSelected: (_) => _goToPly(i + 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GameHeader extends StatelessWidget {
  final ChessGame game;
  const _GameHeader({required this.game});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(
            child: Text(
              '${game.white}${game.whiteRating != null ? ' (${game.whiteRating})' : ''}',
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(game.result, style: const TextStyle(fontWeight: FontWeight.bold)),
          Flexible(
            child: Text(
              '${game.black}${game.blackRating != null ? ' (${game.blackRating})' : ''}',
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

class _EvalAndNavBar extends StatelessWidget {
  final String evalLabel;
  final String? bestMove;
  final MoveClassification? classification;
  final int ply;
  final int totalPlies;
  final VoidCallback onFirst;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onLast;

  const _EvalAndNavBar({
    required this.evalLabel,
    required this.bestMove,
    required this.classification,
    required this.ply,
    required this.totalPlies,
    required this.onFirst,
    required this.onPrev,
    required this.onNext,
    required this.onLast,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Row(
        children: [
          if (bestMove != null)
            Expanded(
              child: Text(
                'أفضل نقلة: $bestMove${classification != null ? '  (${classification!.labelAr})' : ''}',
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13),
              ),
            )
          else
            const Spacer(),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.first_page),
            onPressed: ply > 0 ? onFirst : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.chevron_right),
            onPressed: ply > 0 ? onPrev : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.chevron_left),
            onPressed: ply < totalPlies ? onNext : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.last_page),
            onPressed: ply < totalPlies ? onLast : null,
          ),
        ],
      ),
    );
  }
}
