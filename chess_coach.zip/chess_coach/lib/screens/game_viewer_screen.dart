import 'package:flutter/material.dart';

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import '../services/analysis_engine.dart';
import '../services/board_controller.dart';
import '../services/pgn_parser.dart';
import '../services/stockfish_service.dart';
import '../theme/board_theme.dart';
import '../widgets/chess_board.dart';
import '../widgets/eval_graph.dart';

class GameViewerScreen extends StatefulWidget {
  final ChessGame game;
  const GameViewerScreen({super.key, required this.game});

  @override
  State<GameViewerScreen> createState() => _GameViewerScreenState();
}

class _GameViewerScreenState extends State<GameViewerScreen> {
  late final BoardController _board;
  late final List<String> _fenSequence;
  late final List<String> _sanMoves;
  int _currentPly = 0;

  ChessGame? _analyzedGame;
  bool _isAnalyzing = false;
  int _analyzedCount = 0;
  StockfishService? _engine;
  AnalysisEngine? _analysisEngine;

  @override
  void initState() {
    super.initState();
    _board = BoardController();
    _fenSequence = PgnParser.fenSequence(widget.game.pgn);
    _sanMoves = PgnParser.sanMoves(widget.game.pgn);
    _analyzedGame = widget.game.isAnalyzed ? widget.game : null;
    _board.loadFen(_fenSequence.first);
  }

  @override
  void dispose() {
    _engine?.dispose();
    super.dispose();
  }

  void _goToPly(int ply) {
    if (ply < 0 || ply >= _fenSequence.length) return;
    setState(() {
      _currentPly = ply;
      _board.loadFen(_fenSequence[ply]);
    });
  }

  Future<void> _startAnalysis() async {
    setState(() {
      _isAnalyzing = true;
      _analyzedCount = 0;
    });

    final engine = StockfishService(depth: 16);
    _engine = engine;
    try {
      await engine.init();
      final analysisEngine = AnalysisEngine(engine);
      _analysisEngine = analysisEngine;

      final results = await analysisEngine.analyzeGame(
        widget.game,
        depth: 16,
        onProgress: (done, total) {
          if (mounted) setState(() => _analyzedCount = done);
        },
      );

      if (mounted) {
        setState(() {
          _analyzedGame = widget.game.copyWith(
            analysis: results,
            analyzedAt: DateTime.now(),
          );
          _isAnalyzing = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isAnalyzing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Analysis failed: $e')),
        );
      }
    }
  }

  void _cancelAnalysis() {
    _analysisEngine?.cancel();
    _engine?.stopAnalysis();
  }

  MoveAnalysis? get _currentMoveAnalysis {
    if (_analyzedGame?.analysis == null || _currentPly == 0) return null;
    final idx = _currentPly - 1;
    if (idx < 0 || idx >= _analyzedGame!.analysis!.length) return null;
    return _analyzedGame!.analysis![idx];
  }

  @override
  Widget build(BuildContext context) {
    final analysis = _analyzedGame?.analysis;
    final currentMove = _currentMoveAnalysis;

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.game.white} vs ${widget.game.black}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flip),
            tooltip: 'Flip board',
            onPressed: () => setState(() => _board.toggleFlip()),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _GameHeader(game: widget.game),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: EvalGraph(
                moves: analysis ?? [],
                currentPly: _currentPly,
                onTapPly: _goToPly,
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: AnimatedBuilder(
                  animation: _board,
                  builder: (context, _) {
                    return ChessBoardWidget(
                      board: _board.boardGrid,
                      flipped: _board.flipped,
                      theme: BoardTheme.emerald,
                      lastMoveFrom: _currentPly > 0 && _sanMoves.isNotEmpty
                          ? null
                          : null,
                      kingInCheck: _board.kingInCheck,
                    );
                  },
                ),
              ),
            ),
            _EvalAndNavBar(
              evalLabel: currentMove?.evalAfter.display ??
                  (_currentPly == 0 ? '+0.00' : '—'),
              bestMove: currentMove?.bestMoveSan,
              classification: currentMove?.classification,
              ply: _currentPly,
              totalPlies: _fenSequence.length - 1,
              onFirst: () => _goToPly(0),
              onPrev: () => _goToPly(_currentPly - 1),
              onNext: () => _goToPly(_currentPly + 1),
              onLast: () => _goToPly(_fenSequence.length - 1),
            ),
            if (!widget.game.isAnalyzed && _analyzedGame == null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: _isAnalyzing
                    ? Column(
                        children: [
                          LinearProgressIndicator(
                            value: _sanMoves.isEmpty
                                ? null
                                : _analyzedCount / _sanMoves.length,
                          ),
                          const SizedBox(height: 6),
                          Text('Analyzing $_analyzedCount / ${_sanMoves.length}'),
                          TextButton(
                            onPressed: _cancelAnalysis,
                            child: const Text('Cancel'),
                          ),
                        ],
                      )
                    : FilledButton.icon(
                        onPressed: _startAnalysis,
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text('Analyze with Stockfish'),
                      ),
              ),
            SizedBox(
              height: 64,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _sanMoves.length,
                itemBuilder: (context, i) {
                  final moveNum = (i ~/ 2) + 1;
                  final isWhiteMove = i % 2 == 0;
                  final label = isWhiteMove ? '$moveNum. ${_sanMoves[i]}' : _sanMoves[i];
                  final selected = _currentPly == i + 1;
                  final ma = analysis != null && i < analysis.length ? analysis[i] : null;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 8),
                    child: ChoiceChip(
                      label: Text('$label${ma != null ? ma.classification.symbol : ''}'),
                      selected: selected,
                      onSelected: (_) => _goToPly(i + 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GameHeader extends StatelessWidget {
  final ChessGame game;
  const _GameHeader({required this.game});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('${game.white}${game.whiteRating != null ? ' (${game.whiteRating})' : ''}'),
          Text(game.result, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text('${game.black}${game.blackRating != null ? ' (${game.blackRating})' : ''}'),
        ],
      ),
    );
  }
}

class _EvalAndNavBar extends StatelessWidget {
  final String evalLabel;
  final String? bestMove;
  final MoveClassification? classification;
  final int ply;
  final int totalPlies;
  final VoidCallback onFirst;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onLast;

  const _EvalAndNavBar({
    required this.evalLabel,
    required this.bestMove,
    required this.classification,
    required this.ply,
    required this.totalPlies,
    required this.onFirst,
    required this.onPrev,
    required this.onNext,
    required this.onLast,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Chip(label: Text(evalLabel)),
          const SizedBox(width: 6),
          if (bestMove != null)
            Expanded(
              child: Text(
                'Best: $bestMove${classification != null ? '  (${classification!.label})' : ''}',
                overflow: TextOverflow.ellipsis,
              ),
            )
          else
            const Spacer(),
          IconButton(icon: const Icon(Icons.first_page), onPressed: ply > 0 ? onFirst : null),
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: ply > 0 ? onPrev : null),
          IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: ply < totalPlies ? onNext : null),
          IconButton(
              icon: const Icon(Icons.last_page), onPressed: ply < totalPlies ? onLast : null),
        ],
      ),
    );
  }
}
