import 'package:flutter/material.dart';

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import '../services/analysis_engine.dart';
import '../services/board_controller.dart';
import '../services/pgn_parser.dart';
import '../services/stockfish_service.dart';
import '../theme/board_theme.dart';
import '../widgets/chess_board.dart';
import '../widgets/eval_graph.dart';
import '../widgets/evaluation_bar.dart';

class GameViewerScreen extends StatefulWidget {
  final ChessGame game;
  const GameViewerScreen({super.key, required this.game});

  @override
  State<GameViewerScreen> createState() => _GameViewerScreenState();
}

class _GameViewerScreenState extends State<GameViewerScreen> {
  late final BoardController _board;
  late final List<String> _fenSequence;
  late final List<String> _sanMoves;
  int _currentPly = 0;

  ChessGame? _analyzedGame;
  int _analyzedCount = 0;
  String? _analysisError;
  AnalysisEngine? _analysisEngine;

  // Talks to the single app-wide Stockfish instance — never constructs
  // its own engine, which is what previously caused
  // "Bad state: Multiple instances are not supported, yet." on the
  // second analysis of the app's lifetime.
  final StockfishService _engine = StockfishService.instance;

  @override
  void initState() {
    super.initState();
    _board = BoardController();
    _fenSequence = PgnParser.fenSequence(widget.game.pgn);
    _sanMoves = PgnParser.sanMoves(widget.game.pgn);
    _analyzedGame = widget.game.isAnalyzed ? widget.game : null;
    _board.loadFen(_fenSequence.first);
  }

  // Deliberately no dispose() call on the engine here — the singleton is
  // shared app-wide and stays alive for the whole process lifetime. See
  // StockfishService's doc comment for why disposing/recreating it is
  // exactly the bug this screen used to have.

  void _goToPly(int ply) {
    if (ply < 0 || ply >= _fenSequence.length) return;
    setState(() {
      _currentPly = ply;
      _board.loadFen(_fenSequence[ply]);
    });
  }

  Future<void> _startAnalysis() async {
    if (_engine.isAnalyzing) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('التحليل جارٍ بالفعل')),
      );
      return;
    }

    setState(() {
      _analysisError = null;
      _analyzedCount = 0;
    });

    try {
      await _engine.init();
      final analysisEngine = AnalysisEngine(_engine);
      _analysisEngine = analysisEngine;

      final results = await analysisEngine.analyzeGame(
        widget.game,
        depth: 16,
        onProgress: (done, total) {
          if (mounted) setState(() => _analyzedCount = done);
        },
      );

      if (mounted) {
        setState(() {
          _analyzedGame = widget.game.copyWith(
            analysis: results,
            analyzedAt: DateTime.now(),
          );
        });
      }
    } catch (e, st) {
      // Never silently swallow the real error — log it in full so it's
      // visible in `adb logcat` / Play Console crash reports, while the
      // UI shows a clean Arabic message. This is a translation layer,
      // not a cover-up: the underlying exception is always in the logs.
      debugPrint('Stockfish analysis failed: $e');
      debugPrint('$st');
      if (mounted) {
        setState(() {
          _analysisError = 'تعذر بدء محرك التحليل. جارٍ إعادة المحاولة تلقائيًا...';
        });
      }
      // One automatic retry: the engine's handshake sometimes needs a
      // second attempt on a slow first cold start. This retries on the
      // SAME shared engine instance — it never constructs a new one.
      try {
        await _engine.init();
        final analysisEngine = AnalysisEngine(_engine);
        _analysisEngine = analysisEngine;
        final results = await analysisEngine.analyzeGame(
          widget.game,
          depth: 16,
          onProgress: (done, total) {
            if (mounted) setState(() => _analyzedCount = done);
          },
        );
        if (mounted) {
          setState(() {
            _analyzedGame = widget.game.copyWith(
              analysis: results,
              analyzedAt: DateTime.now(),
            );
            _analysisError = null;
          });
        }
      } catch (e2, st2) {
        debugPrint('Stockfish analysis retry failed: $e2');
        debugPrint('$st2');
        if (mounted) {
          setState(() {
            _analysisError =
                'فشل التحليل. تأكد من اتصالك أو جرّب التحليل المحلي من الإعدادات.';
          });
        }
      }
    }
  }

  void _cancelAnalysis() {
    _analysisEngine?.cancel();
    _engine.stopAnalysis();
  }

  MoveAnalysis? get _currentMoveAnalysis {
    if (_analyzedGame?.analysis == null || _currentPly == 0) return null;
    final idx = _currentPly - 1;
    if (idx < 0 || idx >= _analyzedGame!.analysis!.length) return null;
    return _analyzedGame!.analysis![idx];
  }

  @override
  Widget build(BuildContext context) {
    final analysis = _analyzedGame?.analysis;
    final currentMove = _currentMoveAnalysis;
    final isAnalyzing = _engine.isAnalyzing;
    final screenWidth = MediaQuery.of(context).size.width;
    final boardSize = screenWidth - 24 - 40; // leave room for the eval bar

    // White is always shown at the bottom unless the board is flipped —
    // this is what makes "who is White / who is Black" unambiguous
    // regardless of which side the user happens to be reviewing.
    final whiteAtBottom = !_board.flipped;

    return Scaffold(
      appBar: AppBar(
        title: const Text('تحليل المباراة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flip),
            tooltip: 'قلب الرقعة',
            onPressed: () => setState(() => _board.toggleFlip()),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (analysis != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: EvalGraph(
                  moves: analysis,
                  currentPly: _currentPly,
                  onTapPly: _goToPly,
                ),
              ),
            _PlayerRow(
              name: whiteAtBottom ? widget.game.black : widget.game.white,
              rating: whiteAtBottom ? widget.game.blackRating : widget.game.whiteRating,
              sideLabel: whiteAtBottom ? 'الأسود' : 'الأبيض',
              isWhite: !whiteAtBottom,
              result: widget.game.result,
              showResult: true,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    EvaluationBar(
                      evaluation: currentMove?.evalAfter,
                      height: boardSize,
                      width: 20,
                    ),
                    const SizedBox(width: 6),
                    Expanded(

                      child: AnimatedBuilder(
                        animation: _board,
                        builder: (context, _) {
                          return AspectRatio(
                            aspectRatio: 1,
                            child: ChessBoardWidget(
                              board: _board.boardGrid,
                              flipped: _board.flipped,
                              theme: BoardTheme.wood,
                              kingInCheck: _board.kingInCheck,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _PlayerRow(
              name: whiteAtBottom ? widget.game.white : widget.game.black,
              rating: whiteAtBottom ? widget.game.whiteRating : widget.game.blackRating,
              sideLabel: whiteAtBottom ? 'الأبيض' : 'الأسود',
              isWhite: whiteAtBottom,
              result: widget.game.result,
              showResult: false,
            ),
            _EvalAndNavBar(
              evalLabel: currentMove?.evalAfter.display ??
                  (_currentPly == 0 ? '+0.00' : '—'),
              bestMove: currentMove?.bestMoveSan,
              classification: currentMove?.classification,
              ply: _currentPly,
              totalPlies: _fenSequence.length - 1,
              onFirst: () => _goToPly(0),
              onPrev: () => _goToPly(_currentPly - 1),
              onNext: () => _goToPly(_currentPly + 1),
              onLast: () => _goToPly(_fenSequence.length - 1),
            ),
            if (_analysisError != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Text(
                  _analysisError!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 13),
                ),
              ),
            if (!widget.game.isAnalyzed && _analyzedGame == null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: isAnalyzing
                    ? Column(
                        children: [
                          LinearProgressIndicator(
                            value: _sanMoves.isEmpty
                                ? null
                                : _analyzedCount / _sanMoves.length,
                          ),
                          const SizedBox(height: 4),
                          Text('جارٍ التحليل $_analyzedCount / ${_sanMoves.length}',
                              style: const TextStyle(fontSize: 12)),
                          TextButton(
                            onPressed: _cancelAnalysis,
                            child: const Text('إيقاف التحليل'),
                          ),
                        ],
                      )
                    : SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _startAnalysis,
                          icon: const Icon(Icons.auto_awesome),
                          label: const Text('تحليل باستخدام Stockfish'),
                        ),
                      ),
              ),
            SizedBox(
              height: 56,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _sanMoves.length,
                itemBuilder: (context, i) {
                  final moveNum = (i ~/ 2) + 1;
                  final isWhiteMove = i % 2 == 0;
                  final label = isWhiteMove ? '$moveNum. ${_sanMoves[i]}' : _sanMoves[i];
                  final selected = _currentPly == i + 1;
                  final ma = analysis != null && i < analysis.length ? analysis[i] : null;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                    child: ChoiceChip(
                      label: Text(
                        '$label${ma != null ? ma.classification.symbol : ''}',
                        textDirection: TextDirection.ltr,
                      ),
                      selected: selected,
                      onSelected: (_) => _goToPly(i + 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A clear, compact player identification row — shown above and below the
/// board — so the user never has to guess which side is which. Each side
/// gets a colored disc (white/black), the player's name and rating, and
/// (for the top row only) the final result.
class _PlayerRow extends StatelessWidget {
  final String name;
  final int? rating;
  final String sideLabel; // 'الأبيض' or 'الأسود'
  final bool isWhite;
  final String result;
  final bool showResult;

  const _PlayerRow({
    required this.name,
    required this.rating,
    required this.sideLabel,
    required this.isWhite,
    required this.result,
    required this.showResult,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isWhite ? Colors.white : const Color(0xFF2B2B2B),
              border: Border.all(color: Colors.grey.shade500, width: 1),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: name,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  if (rating != null)
                    TextSpan(
                      text: '  ($rating)',
                      style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                    ),
                  TextSpan(
                    text: '  ·  $sideLabel',
                    style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                  ),
                ],
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (showResult)
            Text(
              result,
              textDirection: TextDirection.ltr,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
        ],
      ),
    );
  }
}

class _EvalAndNavBar extends StatelessWidget {
  final String evalLabel;
  final String? bestMove;
  final MoveClassification? classification;
  final int ply;
  final int totalPlies;
  final VoidCallback onFirst;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onLast;

  const _EvalAndNavBar({
    required this.evalLabel,
    required this.bestMove,
    required this.classification,
    required this.ply,
    required this.totalPlies,
    required this.onFirst,
    required this.onPrev,
    required this.onNext,
    required this.onLast,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Row(
        children: [
          if (bestMove != null)
            Expanded(
              child: Text(
                'أفضل نقلة: $bestMove${classification != null ? '  (${classification!.labelAr})' : ''}',
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13),
              ),
            )
          else
            const Spacer(),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.first_page),
            onPressed: ply > 0 ? onFirst : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.chevron_right),
            onPressed: ply > 0 ? onPrev : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.chevron_left),
            onPressed: ply < totalPlies ? onNext : null,
          ),
          IconButton(
            iconSize: 22,
            icon: const Icon(Icons.last_page),
            onPressed: ply < totalPlies ? onLast : null,
          ),
        ],
      ),
    );
  }
}
