import 'package:flutter/material.dart';

import '../theme/board_theme.dart';
import 'chess_piece_painter.dart';

/// Immutable description of a square, e.g. "e4" -> file 4, rank 4 (0-indexed
/// from White's a1 = (0,0)).
class Square {
  final int file; // 0=a .. 7=h
  final int rank; // 0=1 .. 7=8
  const Square(this.file, this.rank);

  String get name => '${'abcdefgh'[file]}${rank + 1}';

  factory Square.fromName(String name) {
    final file = name.codeUnitAt(0) - 'a'.codeUnitAt(0);
    final rank = int.parse(name[1]) - 1;
    return Square(file, rank);
  }
}

class BoardArrow {
  final Square from;
  final Square to;
  final Color color;
  const BoardArrow(this.from, this.to, {this.color = Colors.orange});
}

/// A premium, original-design chessboard. Renders piece glyphs from a
/// bundled font-free unicode set by default (swap in an asset piece set via
/// [pieceAssetBuilder] for a fully custom look).
class ChessBoardWidget extends StatelessWidget {
  /// 8x8 board state, row 0 = rank 8 (top when White at bottom), using FEN
  /// piece letters ('P','N','B','R','Q','K' uppercase = white) or null.
  final List<List<String?>> board;

  final bool flipped;
  final Square? selected;
  final Set<Square> legalTargets;
  final Square? lastMoveFrom;
  final Square? lastMoveTo;
  final Square? kingInCheck;
  final List<BoardArrow> arrows;
  final BoardArrow? bestMoveArrow;
  final BoardTheme theme;
  final void Function(Square square)? onSquareTap;
  final Widget Function(String pieceCode, double size)? pieceAssetBuilder;

  const ChessBoardWidget({
    super.key,
    required this.board,
    this.flipped = false,
    this.selected,
    this.legalTargets = const {},
    this.lastMoveFrom,
    this.lastMoveTo,
    this.kingInCheck,
    this.arrows = const [],
    this.bestMoveArrow,
    this.theme = BoardTheme.emerald,
    this.onSquareTap,
    this.pieceAssetBuilder,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = constraints.maxWidth;
        final squareSize = size / 8;

        return SizedBox(
          width: size,
          height: size,
          child: Stack(
            children: [
              // Board squares
              Column(
                children: List.generate(8, (displayRow) {
                  return Row(
                    children: List.generate(8, (displayCol) {
                      final square = _squareAt(displayRow, displayCol);
                      final isLight = (square.file + square.rank) % 2 != 0;
                      final isSelected = selected != null &&
                          selected!.file == square.file &&
                          selected!.rank == square.rank;
                      final isLastMove = (lastMoveFrom == square) || (lastMoveTo == square);
                      final isCheck = kingInCheck == square;
                      final isLegalTarget = legalTargets.contains(square);

                      Color bg = isLight ? theme.lightSquare : theme.darkSquare;
                      if (isCheck) {
                        bg = theme.checkHighlight;
                      } else if (isSelected) {
                        bg = theme.selectedHighlight;
                      } else if (isLastMove) {
                        bg = Color.alphaBlend(theme.lastMoveHighlight, bg);
                      }

                      // board[0] is rank 8 (top row when unflipped), so convert
                      // our rank-from-1 Square into that row index.
                      final piece = board[7 - square.rank][square.file];

                      return GestureDetector(
                        onTap: () => onSquareTap?.call(square),
                        child: Container(
                          width: squareSize,
                          height: squareSize,
                          color: bg,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              if (piece != null)
                                pieceAssetBuilder != null
                                    ? pieceAssetBuilder!(piece, squareSize * 0.82)
                                    : ChessPieceWidget(pieceCode: piece, size: squareSize * 0.86),
                              if (isLegalTarget && piece == null)
                                Container(
                                  width: squareSize * 0.32,
                                  height: squareSize * 0.32,
                                  decoration: BoxDecoration(
                                    color: theme.moveHintDot,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              if (isLegalTarget && piece != null)
                                Container(
                                  width: squareSize * 0.92,
                                  height: squareSize * 0.92,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: theme.captureHintRing,
                                      width: 3,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }),
                  );
                }),
              ),

              // Coordinate labels
              ..._buildCoordinateLabels(squareSize),

              // Arrows (engine variations, best move) drawn above pieces.
              IgnorePointer(
                child: CustomPaint(
                  size: Size(size, size),
                  painter: _ArrowPainter(
                    arrows: [
                      ...arrows,
                      if (bestMoveArrow != null) bestMoveArrow!,
                    ],
                    squareSize: squareSize,
                    flipped: flipped,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Square _squareAt(int displayRow, int displayCol) {
    // displayRow 0 = top of screen. When not flipped, top = rank 8 (index 7).
    final rank = flipped ? displayRow : 7 - displayRow;
    final file = flipped ? 7 - displayCol : displayCol;
    return Square(file, rank);
  }

  List<Widget> _buildCoordinateLabels(double squareSize) {
    final files = flipped ? 'hgfedcba' : 'abcdefgh';
    final ranks = flipped ? '12345678' : '87654321';
    final labels = <Widget>[];

    for (var i = 0; i < 8; i++) {
      labels.add(Positioned(
        left: i * squareSize + 2,
        bottom: 2,
        child: Text(
          files[i],
          style: TextStyle(
            fontSize: squareSize * 0.16,
            fontWeight: FontWeight.w600,
            color: (i % 2 == 0) ? theme.darkSquare : theme.lightSquare,
          ),
        ),
      ));
      labels.add(Positioned(
        right: 2,
        top: i * squareSize + 1,
        child: Text(
          ranks[i],
          style: TextStyle(
            fontSize: squareSize * 0.16,
            fontWeight: FontWeight.w600,
            color: (i % 2 == 0) ? theme.lightSquare : theme.darkSquare,
          ),
        ),
      ));
    }
    return labels;
  }
}

class _ArrowPainter extends CustomPainter {
  final List<BoardArrow> arrows;
  final double squareSize;
  final bool flipped;

  _ArrowPainter({required this.arrows, required this.squareSize, required this.flipped});

  Offset _center(Square s) {
    final displayCol = flipped ? 7 - s.file : s.file;
    final displayRow = flipped ? s.rank : 7 - s.rank;
    return Offset(
      displayCol * squareSize + squareSize / 2,
      displayRow * squareSize + squareSize / 2,
    );
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (final arrow in arrows) {
      final from = _center(arrow.from);
      final to = _center(arrow.to);
      final paint = Paint()
        ..color = arrow.color.withOpacity(0.75)
        ..strokeWidth = squareSize * 0.14
        ..strokeCap = StrokeCap.round;

      final direction = (to - from);
      final length = direction.distance;
      if (length < 1) continue;
      final unit = direction / length;
      final shortenedTo = to - unit * squareSize * 0.35;

      canvas.drawLine(from, shortenedTo, paint);

      // Arrowhead
      final headLength = squareSize * 0.28;
      final angle = 0.5;
      final left = shortenedTo -
          Offset(
            unit.dx * headLength * (1) - (-unit.dy) * headLength * angle,
            unit.dy * headLength * (1) - (unit.dx) * headLength * angle,
          );
      final right = shortenedTo -
          Offset(
            unit.dx * headLength * (1) + (-unit.dy) * headLength * angle,
            unit.dy * headLength * (1) + (unit.dx) * headLength * angle,
          );

      final path = Path()
        ..moveTo(shortenedTo.dx, shortenedTo.dy)
        ..lineTo(left.dx, left.dy)
        ..lineTo(right.dx, right.dy)
        ..close();
      canvas.drawPath(path, Paint()..color = arrow.color.withOpacity(0.85));
    }
  }

  @override
  bool shouldRepaint(covariant _ArrowPainter oldDelegate) {
    return oldDelegate.arrows != arrows || oldDelegate.flipped != flipped;
  }
}
