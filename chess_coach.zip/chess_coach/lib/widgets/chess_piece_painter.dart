import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Draws each piece type as an original vector silhouette on a 0-100 unit
/// canvas (scaled to the actual square size by the caller). This exists
/// specifically to replace Unicode chess glyphs (⭘♔♕ etc.), which render
/// inconsistently across Android devices/fonts and look amateurish — every
/// path here is hand-built geometry, not derived from any third-party
/// piece set or font.
class ChessPiecePainter extends CustomPainter {
  final String pieceCode; // e.g. 'K', 'q', 'N', 'p'
  final Color fillColor;
  final Color outlineColor;

  ChessPiecePainter({
    required this.pieceCode,
    required this.fillColor,
    required this.outlineColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 100;
    canvas.save();

    // Soft drop shadow beneath the piece — gives real depth instead of a
    // flat sticker look, without needing any external image asset.
    canvas.save();
    canvas.translate(1.6 * scale, 2.2 * scale);
    canvas.scale(scale, scale);
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(0.28)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.4);
    _paintSilhouetteOnly(canvas, shadowPaint);
    canvas.restore();

    canvas.scale(scale, scale);

    // A subtle top-to-bottom gradient (light catching the top of the
    // piece, darker toward the base) instead of one flat fill color —
    // this is what makes hand-painted vector pieces read as "glossy
    // Staunton wood/plastic" rather than a flat sticker.
    final isWhite = fillColor.computeLuminance() > 0.5;
    final gradientTop = isWhite ? Colors.white : const Color(0xFF3A3A3A);
    final gradientBottom =
        isWhite ? const Color(0xFFD8D0C0) : const Color(0xFF161616);

    final fill = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(50, 6),
        const Offset(50, 88),
        [gradientTop, gradientBottom],
      )
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;
    final stroke = Paint()
      ..color = outlineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;

    final type = pieceCode.toUpperCase();
    switch (type) {
      case 'P':
        _paintPawn(canvas, fill, stroke);
        break;
      case 'R':
        _paintRook(canvas, fill, stroke);
        break;
      case 'N':
        _paintKnight(canvas, fill, stroke);
        break;
      case 'B':
        _paintBishop(canvas, fill, stroke);
        break;
      case 'Q':
        _paintQueen(canvas, fill, stroke);
        break;
      case 'K':
        _paintKing(canvas, fill, stroke);
        break;
    }

    canvas.restore();
  }

  /// Draws just the piece's filled silhouette (fill == stroke == the
  /// given paint) — used to render the blurred drop-shadow layer with the
  /// exact same geometry as the real piece, without duplicating every
  /// shape's path definition.
  void _paintSilhouetteOnly(Canvas canvas, Paint paint) {
    final type = pieceCode.toUpperCase();
    switch (type) {
      case 'P':
        _paintPawn(canvas, paint, paint);
        break;
      case 'R':
        _paintRook(canvas, paint, paint);
        break;
      case 'N':
        _paintKnight(canvas, paint, paint);
        break;
      case 'B':
        _paintBishop(canvas, paint, paint);
        break;
      case 'Q':
        _paintQueen(canvas, paint, paint);
        break;
      case 'K':
        _paintKing(canvas, paint, paint);
        break;
    }
  }

  void _drawPath(Canvas canvas, Path path, Paint fill, Paint stroke) {
    canvas.drawPath(path, fill);
    canvas.drawPath(path, stroke);
  }

  void _paintBase(Canvas canvas, Paint fill, Paint stroke, {double y = 84, double w = 34}) {
    final base = Path()
      ..moveTo(50 - w, y)
      ..lineTo(50 + w, y)
      ..quadraticBezierTo(50 + w + 4, y + 6, 50 + w, y + 10)
      ..lineTo(50 - w, y + 10)
      ..quadraticBezierTo(50 - w - 4, y + 6, 50 - w, y);
    _drawPath(canvas, base, fill, stroke);
  }

  void _paintPawn(Canvas canvas, Paint fill, Paint stroke) {
    final head = Path()..addOval(Rect.fromCircle(center: const Offset(50, 30), radius: 13));
    _drawPath(canvas, head, fill, stroke);

    final body = Path()
      ..moveTo(38, 46)
      ..quadraticBezierTo(50, 40, 62, 46)
      ..lineTo(70, 76)
      ..quadraticBezierTo(50, 82, 30, 76)
      ..close();
    _drawPath(canvas, body, fill, stroke);

    _paintBase(canvas, fill, stroke, y: 76, w: 26);
  }

  void _paintRook(Canvas canvas, Paint fill, Paint stroke) {
    final body = Path()
      ..moveTo(28, 78)
      ..lineTo(28, 40)
      ..lineTo(34, 40)
      ..lineTo(34, 26)
      ..lineTo(44, 26)
      ..lineTo(44, 32)
      ..lineTo(56, 32)
      ..lineTo(56, 26)
      ..lineTo(66, 26)
      ..lineTo(66, 40)
      ..lineTo(72, 40)
      ..lineTo(72, 78)
      ..close();
    _drawPath(canvas, body, fill, stroke);
    _paintBase(canvas, fill, stroke, y: 78, w: 28);
  }

  void _paintBishop(Canvas canvas, Paint fill, Paint stroke) {
    final ball = Path()..addOval(Rect.fromCircle(center: const Offset(50, 16), radius: 5));
    _drawPath(canvas, ball, fill, stroke);

    final body = Path()
      ..moveTo(50, 24)
      ..cubicTo(66, 34, 68, 52, 58, 64)
      ..quadraticBezierTo(66, 70, 66, 78)
      ..quadraticBezierTo(50, 84, 34, 78)
      ..quadraticBezierTo(34, 70, 42, 64)
      ..cubicTo(32, 52, 34, 34, 50, 24)
      ..close();
    _drawPath(canvas, body, fill, stroke);

    // Diagonal slit — the classic bishop marking.
    final slit = Paint()
      ..color = outlineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(43, 42), const Offset(57, 52), slit);
  }

  void _paintKnight(Canvas canvas, Paint fill, Paint stroke) {
    final body = Path()
      ..moveTo(30, 80)
      ..quadraticBezierTo(30, 66, 38, 60)
      ..lineTo(34, 50)
      ..quadraticBezierTo(32, 36, 44, 26)
      ..quadraticBezierTo(52, 18, 64, 22)
      ..quadraticBezierTo(70, 24, 70, 30)
      ..quadraticBezierTo(64, 28, 60, 32)
      ..quadraticBezierTo(68, 34, 70, 42)
      ..quadraticBezierTo(72, 50, 66, 54)
      ..quadraticBezierTo(60, 48, 54, 50)
      ..quadraticBezierTo(58, 56, 56, 62)
      ..lineTo(70, 80)
      ..close();
    _drawPath(canvas, body, fill, stroke);

    // Eye
    final eye = Paint()..color = outlineColor;
    canvas.drawCircle(const Offset(56, 34), 2.2, eye);

    _paintBase(canvas, fill, stroke, y: 80, w: 26);
  }

  void _paintQueen(Canvas canvas, Paint fill, Paint stroke) {
    // Crown points
    for (final dx in [-24.0, -12.0, 0.0, 12.0, 24.0]) {
      final ball = Path()..addOval(Rect.fromCircle(center: Offset(50 + dx, dx == 0 ? 16 : 22), radius: 5));
      _drawPath(canvas, ball, fill, stroke);
    }

    final crown = Path()
      ..moveTo(26, 46)
      ..lineTo(32, 24)
      ..lineTo(41, 40)
      ..lineTo(50, 20)
      ..lineTo(59, 40)
      ..lineTo(68, 24)
      ..lineTo(74, 46)
      ..close();
    _drawPath(canvas, crown, fill, stroke);

    final body = Path()
      ..moveTo(30, 46)
      ..lineTo(70, 46)
      ..lineTo(64, 76)
      ..quadraticBezierTo(50, 82, 36, 76)
      ..close();
    _drawPath(canvas, body, fill, stroke);

    _paintBase(canvas, fill, stroke, y: 76, w: 28);
  }

  void _paintKing(Canvas canvas, Paint fill, Paint stroke) {
    // Cross on top
    final cross = Path()
      ..moveTo(47, 8)
      ..lineTo(53, 8)
      ..lineTo(53, 14)
      ..lineTo(59, 14)
      ..lineTo(59, 20)
      ..lineTo(53, 20)
      ..lineTo(53, 26)
      ..lineTo(47, 26)
      ..lineTo(47, 20)
      ..lineTo(41, 20)
      ..lineTo(41, 14)
      ..lineTo(47, 14)
      ..close();
    _drawPath(canvas, cross, fill, stroke);

    final crown = Path()
      ..moveTo(28, 48)
      ..lineTo(34, 30)
      ..lineTo(50, 42)
      ..lineTo(66, 30)
      ..lineTo(72, 48)
      ..close();
    _drawPath(canvas, crown, fill, stroke);

    final body = Path()
      ..moveTo(30, 48)
      ..lineTo(70, 48)
      ..lineTo(64, 78)
      ..quadraticBezierTo(50, 84, 36, 78)
      ..close();
    _drawPath(canvas, body, fill, stroke);

    _paintBase(canvas, fill, stroke, y: 78, w: 28);
  }

  @override
  bool shouldRepaint(covariant ChessPiecePainter oldDelegate) {
    return oldDelegate.pieceCode != pieceCode ||
        oldDelegate.fillColor != fillColor ||
        oldDelegate.outlineColor != outlineColor;
  }
}

/// Widget wrapper so callers can drop a piece in like any other widget.
class ChessPieceWidget extends StatelessWidget {
  final String pieceCode;
  final double size;

  const ChessPieceWidget({super.key, required this.pieceCode, required this.size});

  @override
  Widget build(BuildContext context) {
    final isWhite = pieceCode == pieceCode.toUpperCase();
    return CustomPaint(
      size: Size(size, size),
      painter: ChessPiecePainter(
        pieceCode: pieceCode,
        fillColor: isWhite ? Colors.white : const Color(0xFF2B2B2B),
        outlineColor: isWhite ? const Color(0xFF2B2B2B) : Colors.white,
      ),
    );
  }
}
