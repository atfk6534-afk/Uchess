import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/move_analysis.dart';

/// Vertical black/white split bar showing who's winning, matching the
/// visual pattern of modern chess analysis apps (an original
/// implementation — plain rectangles and a label, not any copied asset).
class EvaluationBar extends StatelessWidget {
  final Evaluation? evaluation;
  final double height;
  final double width;

  const EvaluationBar({
    super.key,
    required this.evaluation,
    this.height = 320,
    this.width = 26,
  });

  @override
  Widget build(BuildContext context) {
    // 0.5 = dead equal. 1.0 = White completely winning. 0.0 = Black completely winning.
    double whiteFraction = 0.5;
    String label = '0.0';

    if (evaluation != null) {
      if (evaluation!.isMate) {
        final mate = evaluation!.mateIn!;
        whiteFraction = mate > 0 ? 0.97 : 0.03;
        label = 'M${mate.abs()}';
      } else {
        final cp = (evaluation!.centipawns ?? 0).toDouble();
        // Same logistic curve used for accuracy elsewhere, mapped to 0..1.
        final clamped = cp.clamp(-1000, 1000);
        whiteFraction = 1 / (1 + _expNeg(-0.004 * clamped));
        final pawns = cp / 100.0;
        label = (pawns >= 0 ? '+' : '') + pawns.toStringAsFixed(1);
      }
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: Colors.black26),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              Expanded(
                flex: ((1 - whiteFraction) * 1000).round().clamp(1, 999).toInt(),
                child: Container(color: const Color(0xFF2B2B2B)),
              ),
              Expanded(
                flex: (whiteFraction * 1000).round().clamp(1, 999).toInt(),
                child: Container(color: Colors.white),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

double _expNeg(double x) => math.exp(x);
