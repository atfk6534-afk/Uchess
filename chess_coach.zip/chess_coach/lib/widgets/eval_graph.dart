import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../models/move_analysis.dart';

class EvalGraph extends StatelessWidget {
  final List<MoveAnalysis> moves;
  final int currentPly; // 0 = start position
  final void Function(int ply) onTapPly;

  const EvalGraph({
    super.key,
    required this.moves,
    required this.currentPly,
    required this.onTapPly,
  });

  @override
  Widget build(BuildContext context) {
    if (moves.isEmpty) {
      return const SizedBox(
        height: 90,
        child: Center(child: Text('Analyze this game to see the evaluation graph.')),
      );
    }

    final spots = <FlSpot>[
      const FlSpot(0, 0),
      ...moves.asMap().entries.map((e) {
        final clamped = e.value.evalAfter.score.clamp(-800.0, 800.0);
        return FlSpot((e.key + 1).toDouble(), clamped / 100.0);
      }),
    ];

    return SizedBox(
      height: 110,
      child: GestureDetector(
        onTapUp: (details) {
          final box = context.findRenderObject() as RenderBox;
          final localX = details.localPosition.dx;
          final ratio = (localX / box.size.width).clamp(0.0, 1.0);
          final ply = (ratio * moves.length).round().clamp(0, moves.length);
          onTapPly(ply);
        },
        child: LineChart(
          LineChartData(
            minY: -8,
            maxY: 8,
            gridData: const FlGridData(show: false),
            titlesData: const FlTitlesData(show: false),
            borderData: FlBorderData(show: false),
            extraLinesData: ExtraLinesData(horizontalLines: [
              HorizontalLine(y: 0, color: Colors.grey.shade400, strokeWidth: 1),
            ]),
            lineTouchData: const LineTouchData(enabled: false),
            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: false,
                barWidth: 2,
                color: Theme.of(context).colorScheme.primary,
                dotData: const FlDotData(show: false),
                belowBarData: BarAreaData(
                  show: true,
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.white.withOpacity(0.85),
                      Colors.white.withOpacity(0.1),
                    ],
                  ),
                ),
              ),
            ],
            showingTooltipIndicators: [],
          ),
        ),
      ),
    );
  }
}
