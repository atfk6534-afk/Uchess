import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';
import 'services/game_repository.dart';

void main() {
  runApp(const ChessCoachApp());
}

class ChessCoachApp extends StatefulWidget {
  const ChessCoachApp({super.key});

  @override
  State<ChessCoachApp> createState() => _ChessCoachAppState();
}

class _ChessCoachAppState extends State<ChessCoachApp> {
  final GameRepository _repository = GameRepository();
  final AppSettings _settings = AppSettings();

  @override
  void initState() {
    super.initState();
    _repository.loadFromDisk();
  }

  @override
  Widget build(BuildContext context) {
    final seed = const Color(0xFF3B7A57);
    return MaterialApp(
      title: 'مدرب الشطرنج',
      debugShowCheckedModeBanner: false,
      // Arabic-first, right-to-left by default.
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      builder: (context, child) {
        // Belt-and-suspenders: force RTL directionality regardless of how
        // the locale resolves, since chess notation (e4, Nf3, PGN strings)
        // must render as plain LTR fragments inside an otherwise-RTL UI —
        // Directionality here governs layout direction, not text runs, so
        // individual notation Text widgets stay readable via their own
        // TextDirection.ltr where used.
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: HomeShell(repository: _repository, settings: _settings),
    );
  }
}
