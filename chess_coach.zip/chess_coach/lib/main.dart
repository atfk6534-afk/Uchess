import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'screens/settings_screen.dart';
import 'services/game_repository.dart';

void main() {
  runApp(const ChessCoachApp());
}

class ChessCoachApp extends StatefulWidget {
  const ChessCoachApp({super.key});

  @override
  State<ChessCoachApp> createState() => _ChessCoachAppState();
}

class _ChessCoachAppState extends State<ChessCoachApp> {
  final GameRepository _repository = GameRepository();
  final AppSettings _settings = AppSettings();

  @override
  void initState() {
    super.initState();
    _repository.loadFromDisk();
  }

  @override
  Widget build(BuildContext context) {
    final seed = const Color(0xFF3B7A57);
    return MaterialApp(
      title: 'Chess Coach',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: HomeShell(repository: _repository, settings: _settings),
    );
  }
}
