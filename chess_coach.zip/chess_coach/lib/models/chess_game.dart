import 'dart:math' as math;

import 'move_analysis.dart';

enum GameSource { pgnImport, chessCom, lichess, urlImport }

enum TimeControlCategory { bullet, blitz, rapid, classical, unknown }

class ChessGame {
  final String id;
  final String pgn;
  final String white;
  final String black;
  final String result; // "1-0", "0-1", "1/2-1/2", "*"
  final DateTime? date;
  final String? eco;
  final String? opening;
  final String timeControl;
  final TimeControlCategory timeControlCategory;
  final int? whiteRating;
  final int? blackRating;
  final GameSource source;

  /// Populated once the game has been analyzed with Stockfish.
  final List<MoveAnalysis>? analysis;
  final DateTime? analyzedAt;

  const ChessGame({
    required this.id,
    required this.pgn,
    required this.white,
    required this.black,
    required this.result,
    this.date,
    this.eco,
    this.opening,
    this.timeControl = '',
    this.timeControlCategory = TimeControlCategory.unknown,
    this.whiteRating,
    this.blackRating,
    this.source = GameSource.pgnImport,
    this.analysis,
    this.analyzedAt,
  });

  bool get isAnalyzed => analysis != null && analysis!.isNotEmpty;

  int get moveCount {
    if (analysis != null) return analysis!.length;
    return 0;
  }

  /// Average accuracy 0-100 for a given color, derived from analyzed moves.
  /// Uses a simple win-probability-based accuracy formula (à la Lichess),
  /// not a naive "1 - avgCentipawnLoss" ratio, so occasional big blunders
  /// don't linearly wreck the whole game score.
  double accuracyFor(bool white) {
    if (analysis == null || analysis!.isEmpty) return 0;
    final moves = analysis!
        .where((m) => (m.fenBefore.split(' ')[1] == 'w') == white)
        .toList();
    if (moves.isEmpty) return 0;

    double winPercent(double cp) {
      // Standard logistic mapping from centipawns to win% (0-100),
      // from the perspective of the side to move.
      final clamped = cp.clamp(-1000, 1000);
      return 50 + 50 * (2 / (1 + _exp(-0.00368208 * clamped)) - 1);
    }

    double totalAccuracy = 0;
    for (final m in moves) {
      final before = white ? m.evalBefore.score : -m.evalBefore.score;
      final after = white ? m.evalAfter.score : -m.evalAfter.score;
      final wpBefore = winPercent(before);
      final wpAfter = winPercent(after);
      final loss = (wpBefore - wpAfter).clamp(0, 100);
      final moveAccuracy = 103.1668 * _expNeg(-0.04354 * loss) - 3.1668;
      totalAccuracy += moveAccuracy.clamp(0, 100);
    }
    return totalAccuracy / moves.length;
  }

  ChessGame copyWith({
    List<MoveAnalysis>? analysis,
    DateTime? analyzedAt,
  }) {
    return ChessGame(
      id: id,
      pgn: pgn,
      white: white,
      black: black,
      result: result,
      date: date,
      eco: eco,
      opening: opening,
      timeControl: timeControl,
      timeControlCategory: timeControlCategory,
      whiteRating: whiteRating,
      blackRating: blackRating,
      source: source,
      analysis: analysis ?? this.analysis,
      analyzedAt: analyzedAt ?? this.analyzedAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'pgn': pgn,
        'white': white,
        'black': black,
        'result': result,
        'date': date?.toIso8601String(),
        'eco': eco,
        'opening': opening,
        'timeControl': timeControl,
        'timeControlCategory': timeControlCategory.name,
        'whiteRating': whiteRating,
        'blackRating': blackRating,
        'source': source.name,
        'analysis': analysis?.map((a) => a.toJson()).toList(),
        'analyzedAt': analyzedAt?.toIso8601String(),
      };

  factory ChessGame.fromJson(Map<String, dynamic> json) => ChessGame(
        id: json['id'] as String,
        pgn: json['pgn'] as String,
        white: json['white'] as String,
        black: json['black'] as String,
        result: json['result'] as String,
        date: json['date'] != null ? DateTime.parse(json['date']) : null,
        eco: json['eco'] as String?,
        opening: json['opening'] as String?,
        timeControl: json['timeControl'] as String? ?? '',
        timeControlCategory: TimeControlCategory.values.byName(
            json['timeControlCategory'] as String? ?? 'unknown'),
        whiteRating: json['whiteRating'] as int?,
        blackRating: json['blackRating'] as int?,
        source: GameSource.values.byName(json['source'] as String? ?? 'pgnImport'),
        analysis: (json['analysis'] as List?)
            ?.map((e) => MoveAnalysis.fromJson(e as Map<String, dynamic>))
            .toList(),
        analyzedAt: json['analyzedAt'] != null
            ? DateTime.parse(json['analyzedAt'])
            : null,
      );
}

double _exp(double x) => math.exp(x);

double _expNeg(double x) => math.exp(x);
