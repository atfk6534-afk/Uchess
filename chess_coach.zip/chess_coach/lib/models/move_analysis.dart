/// Classification of a played move, from best to worst.
/// Ordering matters: index is used to compare severity.
enum MoveClassification {
  brilliant, // !! - a sacrifice or only move that is objectively best and hard to find
  best, // engine's #1 choice
  excellent, // very close to best, keeps full advantage
  good, // reasonable, small eval loss
  book, // known opening theory
  inaccuracy, // ?! - small but real eval loss
  mistake, // ? - clear eval loss, gives opponent a real chance
  missedWin, // had a forced win / big advantage and let it slip
  blunder, // ?? - large eval loss, often loses material or the game
}

extension MoveClassificationX on MoveClassification {
  String get label {
    switch (this) {
      case MoveClassification.brilliant:
        return 'Brilliant';
      case MoveClassification.best:
        return 'Best';
      case MoveClassification.excellent:
        return 'Excellent';
      case MoveClassification.good:
        return 'Good';
      case MoveClassification.book:
        return 'Book';
      case MoveClassification.inaccuracy:
        return 'Inaccuracy';
      case MoveClassification.mistake:
        return 'Mistake';
      case MoveClassification.missedWin:
        return 'Missed Win';
      case MoveClassification.blunder:
        return 'Blunder';
    }
  }

  String get symbol {
    switch (this) {
      case MoveClassification.brilliant:
        return '!!';
      case MoveClassification.best:
        return '★';
      case MoveClassification.excellent:
        return '!';
      case MoveClassification.good:
        return '';
      case MoveClassification.book:
        return '📖';
      case MoveClassification.inaccuracy:
        return '?!';
      case MoveClassification.mistake:
        return '?';
      case MoveClassification.missedWin:
        return '⌛';
      case MoveClassification.blunder:
        return '??';
    }
  }
}

/// A single centipawn/mate evaluation from Stockfish, from the side-to-move's
/// perspective at the time it was requested, normalized to White's perspective
/// for storage (positive = good for White).
class Evaluation {
  /// Centipawn score. Null when [mateIn] is set.
  final int? centipawns;

  /// Positive = White mates in N, negative = Black mates in N. Null if no mate.
  final int? mateIn;

  final int depth;

  const Evaluation({this.centipawns, this.mateIn, required this.depth});

  bool get isMate => mateIn != null;

  /// A single sortable number for graphing / comparisons, in centipawns,
  /// clamped so mate scores sit beyond normal eval range.
  double get score {
    if (mateIn != null) {
      return mateIn! > 0 ? 10000.0 - mateIn! : -10000.0 - mateIn!;
    }
    return (centipawns ?? 0).toDouble();
  }

  String get display {
    if (mateIn != null) {
      return 'M${mateIn!.abs()}';
    }
    final cp = (centipawns ?? 0) / 100.0;
    final sign = cp > 0 ? '+' : '';
    return '$sign${cp.toStringAsFixed(2)}';
  }

  Map<String, dynamic> toJson() => {
        'centipawns': centipawns,
        'mateIn': mateIn,
        'depth': depth,
      };

  factory Evaluation.fromJson(Map<String, dynamic> json) => Evaluation(
        centipawns: json['centipawns'] as int?,
        mateIn: json['mateIn'] as int?,
        depth: json['depth'] as int? ?? 0,
      );
}

/// Full analysis of a single played move (ply) in a game.
class MoveAnalysis {
  final int plyNumber; // 1-indexed half-move count
  final String sanMove; // move actually played, e.g. "Nf3"
  final String fenBefore;
  final String fenAfter;
  final Evaluation evalBefore;
  final Evaluation evalAfter;
  final String bestMoveSan;
  final String principalVariation; // space separated SAN
  final MoveClassification classification;

  /// Short human/coach explanation of why the move was good or bad.
  final String? explanation;

  /// Tags used later for "learn from my mistakes" pattern detection,
  /// e.g. "hanging_piece", "missed_threat", "back_rank".
  final List<String> tags;

  const MoveAnalysis({
    required this.plyNumber,
    required this.sanMove,
    required this.fenBefore,
    required this.fenAfter,
    required this.evalBefore,
    required this.evalAfter,
    required this.bestMoveSan,
    required this.principalVariation,
    required this.classification,
    this.explanation,
    this.tags = const [],
  });

  /// Eval swing in centipawns from the perspective of the player who moved.
  /// Positive means the move was bad for them (they lost ground).
  double get evalLossForMover {
    final whiteToMove = fenBefore.split(' ')[1] == 'w';
    final before = evalBefore.score;
    final after = evalAfter.score;
    // Convert both to "mover's perspective" (positive = good for mover)
    final beforeForMover = whiteToMove ? before : -before;
    final afterForMover = whiteToMove ? after : -after;
    return beforeForMover - afterForMover;
  }

  Map<String, dynamic> toJson() => {
        'plyNumber': plyNumber,
        'sanMove': sanMove,
        'fenBefore': fenBefore,
        'fenAfter': fenAfter,
        'evalBefore': evalBefore.toJson(),
        'evalAfter': evalAfter.toJson(),
        'bestMoveSan': bestMoveSan,
        'principalVariation': principalVariation,
        'classification': classification.name,
        'explanation': explanation,
        'tags': tags,
      };

  factory MoveAnalysis.fromJson(Map<String, dynamic> json) => MoveAnalysis(
        plyNumber: json['plyNumber'] as int,
        sanMove: json['sanMove'] as String,
        fenBefore: json['fenBefore'] as String,
        fenAfter: json['fenAfter'] as String,
        evalBefore: Evaluation.fromJson(json['evalBefore']),
        evalAfter: Evaluation.fromJson(json['evalAfter']),
        bestMoveSan: json['bestMoveSan'] as String,
        principalVariation: json['principalVariation'] as String,
        classification:
            MoveClassification.values.byName(json['classification'] as String),
        explanation: json['explanation'] as String?,
        tags: (json['tags'] as List?)?.map((e) => e as String).toList() ?? [],
      );
}
