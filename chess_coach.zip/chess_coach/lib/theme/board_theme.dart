import 'package:flutter/material.dart';

/// Original, non-copyrighted board color palettes. Names are ours.
class BoardTheme {
  final String name;
  final Color lightSquare;
  final Color darkSquare;
  final Color selectedHighlight;
  final Color lastMoveHighlight; // alpha-blended over the square color
  final Color checkHighlight;
  final Color moveHintDot;
  final Color captureHintRing;

  const BoardTheme({
    required this.name,
    required this.lightSquare,
    required this.darkSquare,
    required this.selectedHighlight,
    required this.lastMoveHighlight,
    required this.checkHighlight,
    required this.moveHintDot,
    required this.captureHintRing,
  });

  static const emerald = BoardTheme(
    name: 'Emerald',
    lightSquare: Color(0xFFEDEED1),
    darkSquare: Color(0xFF6E9A5D),
    selectedHighlight: Color(0xFFF6F589),
    lastMoveHighlight: Color(0x66F6F589),
    checkHighlight: Color(0xFFEF5350),
    moveHintDot: Color(0x552B2B2B),
    captureHintRing: Color(0x772B2B2B),
  );

  static const midnight = BoardTheme(
    name: 'Midnight',
    lightSquare: Color(0xFF8DA7C4),
    darkSquare: Color(0xFF3B4E68),
    selectedHighlight: Color(0xFFE0C341),
    lastMoveHighlight: Color(0x55E0C341),
    checkHighlight: Color(0xFFE05858),
    moveHintDot: Color(0x66102030),
    captureHintRing: Color(0x88102030),
  );

  static const walnut = BoardTheme(
    name: 'Walnut',
    lightSquare: Color(0xFFE8D0AA),
    darkSquare: Color(0xFF9C6B3E),
    selectedHighlight: Color(0xFFB6E38A),
    lastMoveHighlight: Color(0x55B6E38A),
    checkHighlight: Color(0xFFD9483C),
    moveHintDot: Color(0x553A2A18),
    captureHintRing: Color(0x883A2A18),
  );

  static const coral = BoardTheme(
    name: 'Coral',
    lightSquare: Color(0xFFFDEDE3),
    darkSquare: Color(0xFFE08E79),
    selectedHighlight: Color(0xFF8FD3C7),
    lastMoveHighlight: Color(0x558FD3C7),
    checkHighlight: Color(0xFFC0392B),
    moveHintDot: Color(0x554A2C22),
    captureHintRing: Color(0x884A2C22),
  );

  static const List<BoardTheme> all = [emerald, midnight, walnut, coral];
}
