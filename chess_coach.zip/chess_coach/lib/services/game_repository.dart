import 'package:flutter/foundation.dart';

import '../models/chess_game.dart';
import 'chesscom_service.dart';
import 'game_database.dart';
import 'lichess_service.dart';

class GameRepository extends ChangeNotifier {
  final ChessComService _chessCom = ChessComService();
  final LichessService _lichess = LichessService();

  List<ChessGame> games = [];
  bool isLoading = false;
  String? lastError;

  Future<void> loadFromDisk() async {
    isLoading = true;
    notifyListeners();
    games = await GameDatabase.getAllGames();
    isLoading = false;
    notifyListeners();
  }

  Future<void> addGame(ChessGame game) async {
    await GameDatabase.upsertGame(game);
    games.insert(0, game);
    notifyListeners();
  }

  Future<void> updateGame(ChessGame game) async {
    await GameDatabase.upsertGame(game);
    final idx = games.indexWhere((g) => g.id == game.id);
    if (idx >= 0) {
      games[idx] = game;
    } else {
      games.insert(0, game);
    }
    notifyListeners();
  }

  Future<void> deleteGame(String id) async {
    await GameDatabase.deleteGame(id);
    games.removeWhere((g) => g.id == id);
    notifyListeners();
  }

  /// Syncs recent games from a Chess.com username. Respects Chess.com's
  /// public API being unauthenticated/read-only — no rate-limit headers to
  /// honor beyond "don't hammer it", so this fetches archives sequentially
  /// rather than in parallel.
  Future<int> syncChessCom(String username, {int maxGames = 20}) async {
    isLoading = true;
    lastError = null;
    notifyListeners();
    try {
      final fetched = await _chessCom.getRecentGames(username, maxGames: maxGames);
      var added = 0;
      for (final g in fetched) {
        final alreadyExists = games.any((existing) => existing.pgn == g.pgn);
        if (!alreadyExists) {
          await addGame(g);
          added++;
        }
      }
      return added;
    } catch (e) {
      lastError = e.toString();
      rethrow;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<int> syncLichess({int maxGames = 20}) async {
    isLoading = true;
    lastError = null;
    notifyListeners();
    try {
      final fetched = await _lichess.getRecentGames(maxGames: maxGames);
      var added = 0;
      for (final g in fetched) {
        final alreadyExists = games.any((existing) => existing.pgn == g.pgn);
        if (!alreadyExists) {
          await addGame(g);
          added++;
        }
      }
      return added;
    } catch (e) {
      lastError = e.toString();
      rethrow;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
