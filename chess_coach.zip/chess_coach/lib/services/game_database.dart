import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../models/chess_game.dart';

/// Offline-first local store. Every table here is designed so a future
/// cloud-sync feature can add a `synced_at` / `remote_id` column without
/// restructuring anything — see README > Database section.
class GameDatabase {
  static Database? _db;

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'chess_coach.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE games (
            id TEXT PRIMARY KEY,
            pgn TEXT NOT NULL,
            white TEXT NOT NULL,
            black TEXT NOT NULL,
            result TEXT NOT NULL,
            date TEXT,
            eco TEXT,
            opening TEXT,
            time_control TEXT,
            time_control_category TEXT,
            white_rating INTEGER,
            black_rating INTEGER,
            source TEXT NOT NULL,
            analysis_json TEXT,
            analyzed_at TEXT
          )
        ''');
        await db.execute('CREATE INDEX idx_games_date ON games(date)');
        await db.execute('CREATE INDEX idx_games_source ON games(source)');

        await db.execute('''
          CREATE TABLE preferences (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE training_positions (
            id TEXT PRIMARY KEY,
            source_game_id TEXT,
            fen TEXT NOT NULL,
            correct_move_san TEXT NOT NULL,
            tag TEXT NOT NULL,
            explanation TEXT,
            created_at TEXT NOT NULL,
            last_practiced_at TEXT,
            times_correct INTEGER NOT NULL DEFAULT 0,
            times_incorrect INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(source_game_id) REFERENCES games(id)
          )
        ''');
      },
    );
    return _db!;
  }

  static Future<void> upsertGame(ChessGame game) async {
    final db = await _open();
    await db.insert(
      'games',
      {
        'id': game.id,
        'pgn': game.pgn,
        'white': game.white,
        'black': game.black,
        'result': game.result,
        'date': game.date?.toIso8601String(),
        'eco': game.eco,
        'opening': game.opening,
        'time_control': game.timeControl,
        'time_control_category': game.timeControlCategory.name,
        'white_rating': game.whiteRating,
        'black_rating': game.blackRating,
        'source': game.source.name,
        'analysis_json':
            game.analysis != null ? jsonEncode(game.analysis!.map((a) => a.toJson()).toList()) : null,
        'analyzed_at': game.analyzedAt?.toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<List<ChessGame>> getAllGames() async {
    final db = await _open();
    final rows = await db.query('games', orderBy: 'date DESC');
    return rows.map(_rowToGame).toList();
  }

  static Future<ChessGame?> getGame(String id) async {
    final db = await _open();
    final rows = await db.query('games', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return _rowToGame(rows.first);
  }

  static Future<void> deleteGame(String id) async {
    final db = await _open();
    await db.delete('games', where: 'id = ?', whereArgs: [id]);
  }

  static ChessGame _rowToGame(Map<String, Object?> row) {
    return ChessGame.fromJson({
      'id': row['id'],
      'pgn': row['pgn'],
      'white': row['white'],
      'black': row['black'],
      'result': row['result'],
      'date': row['date'],
      'eco': row['eco'],
      'opening': row['opening'],
      'timeControl': row['time_control'] ?? '',
      'timeControlCategory': row['time_control_category'] ?? 'unknown',
      'whiteRating': row['white_rating'],
      'blackRating': row['black_rating'],
      'source': row['source'],
      'analysis': row['analysis_json'] != null
          ? jsonDecode(row['analysis_json'] as String)
          : null,
      'analyzedAt': row['analyzed_at'],
    });
  }

  static Future<void> setPreference(String key, String value) async {
    final db = await _open();
    await db.insert('preferences', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<String?> getPreference(String key) async {
    final db = await _open();
    final rows = await db.query('preferences', where: 'key = ?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }
}
