import 'package:chess/chess.dart' as chesslib;

import '../models/chess_game.dart';
import '../models/move_analysis.dart';
import 'chess_notation_utils.dart';
import 'pgn_parser.dart';
import 'stockfish_service.dart';

/// Progress callback: (movesAnalyzed, totalMoves).
typedef AnalysisProgressCallback = void Function(int done, int total);

/// Orchestrates full-game analysis: walks every ply, asks Stockfish for the
/// eval before and after, converts UCI best-move to SAN, and classifies the
/// move using context-aware thresholds (not a flat centipawn cutoff).
class AnalysisEngine {
  final StockfishService engine;
  bool _cancelled = false;

  AnalysisEngine(this.engine);

  void cancel() => _cancelled = true;

  Future<List<MoveAnalysis>> analyzeGame(
    ChessGame game, {
    int depth = 16,
    AnalysisProgressCallback? onProgress,
  }) async {
    _cancelled = false;
    final sanMoves = PgnParser.sanMoves(game.pgn);
    final replay = chesslib.Chess();

    final results = <MoveAnalysis>[];

    // Each board position gets analyzed exactly once. A move's "after"
    // position is identical to the *next* move's "before" position, so the
    // engine result computed at the end of one iteration is reused as the
    // next iteration's starting point instead of asking Stockfish again.
    EngineResult? cachedResult;

    for (var i = 0; i < sanMoves.length; i++) {
      if (_cancelled) break;

      final fenBefore = replay.fen;

      final beforeResult =
          cachedResult ?? await engine.analyzePosition(fenBefore, searchDepth: depth);
      final beforeEval = beforeResult.evaluation;
      final bestMoveSan = _uciToSan(replay, beforeResult.bestMoveUci);
      final pvSan = _pvToSan(replay, beforeResult.principalVariationUci);

      final san = sanMoves[i];
      final ok = replay.move(san);
      if (!ok) {
        throw Exception('Failed to replay move "$san" (ply ${i + 1}) during analysis.');
      }
      final fenAfter = replay.fen;

      final afterResult = await engine.analyzePosition(fenAfter, searchDepth: depth);
      final afterEval = afterResult.evaluation;
      cachedResult = afterResult;

      final isBookMove = i < 10 && san == bestMoveSan;

      final classification = _classify(
        plyIndex: i,
        fenBeforeMove: fenBefore,
        played: san,
        best: bestMoveSan,
        evalBefore: beforeEval,
        evalAfter: afterEval,
        isBookMove: isBookMove,
      );

      results.add(MoveAnalysis(
        plyNumber: i + 1,
        sanMove: san,
        fenBefore: fenBefore,
        fenAfter: fenAfter,
        evalBefore: beforeEval,
        evalAfter: afterEval,
        bestMoveSan: bestMoveSan,
        principalVariation: pvSan.join(' '),
        classification: classification,
        explanation: _explain(classification, san, bestMoveSan),
        tags: _detectTags(classification, beforeEval, afterEval),
      ));

      onProgress?.call(i + 1, sanMoves.length);
    }

    return results;
  }

  /// Context-aware classification. Rather than a single fixed centipawn
  /// cutoff for every position, the thresholds shift based on:
  ///  - how large the swing was (evalLoss)
  ///  - whether the position was already winning/losing before the move
  ///  - whether a forced mate was missed or thrown away
  ///  - whether the move matched the engine's top choice exactly
  MoveClassification _classify({
    required int plyIndex,
    required String fenBeforeMove,
    required String played,
    required String best,
    required Evaluation evalBefore,
    required Evaluation evalAfter,
    required bool isBookMove,
  }) {
    if (isBookMove) return MoveClassification.book;

    final whiteToMove = fenBeforeMove.split(' ')[1] == 'w';
    final beforeForMover = whiteToMove ? evalBefore.score : -evalBefore.score;
    final afterForMover = whiteToMove ? evalAfter.score : -evalAfter.score;
    final loss = beforeForMover - afterForMover; // positive = got worse

    final matchedBest = played == best;

    // Missed / thrown-away forced mate takes priority over everything else.
    final hadMateBefore = evalBefore.isMate &&
        ((whiteToMove && (evalBefore.mateIn ?? 0) > 0) ||
            (!whiteToMove && (evalBefore.mateIn ?? 0) < 0));
    final stillHasMateAfter = evalAfter.isMate &&
        ((whiteToMove && (evalAfter.mateIn ?? 0) > 0) ||
            (!whiteToMove && (evalAfter.mateIn ?? 0) < 0));
    if (hadMateBefore && !stillHasMateAfter) {
      return MoveClassification.missedWin;
    }

    if (matchedBest) {
      // Even the engine's top move can be a "brilliant" if it was a
      // non-obvious sacrifice that keeps/creates a big advantage from a
      // roughly equal or worse position.
      final wasWorseOrEqual = beforeForMover <= 50;
      final nowClearlyBetter = afterForMover >= 150;
      if (wasWorseOrEqual && nowClearlyBetter) {
        return MoveClassification.brilliant;
      }
      return MoveClassification.best;
    }

    // Was the position already decisively lost before this move? If so,
    // don't pile on extra "blunder" labels for a lost position — cap
    // severity, since there's little practical difference between -8 and -12.
    final alreadyLost = beforeForMover <= -600;
    final alreadyWinning = beforeForMover >= 600;

    if (loss <= 10) return MoveClassification.excellent;
    if (loss <= 30) return MoveClassification.good;
    if (loss <= 90) return MoveClassification.inaccuracy;

    if (alreadyLost) {
      // Position was already lost — don't over-penalize; cap at mistake.
      return loss <= 250 ? MoveClassification.inaccuracy : MoveClassification.mistake;
    }

    if (loss <= 200) return MoveClassification.mistake;

    if (alreadyWinning && loss > 200) {
      // Threw away a large advantage.
      return MoveClassification.missedWin;
    }

    return MoveClassification.blunder;
  }

  List<String> _detectTags(
    MoveClassification c,
    Evaluation before,
    Evaluation after,
  ) {
    final tags = <String>[];
    if (c == MoveClassification.blunder) tags.add('blunder');
    if (c == MoveClassification.missedWin) tags.add('missed_win');
    if (c == MoveClassification.mistake) tags.add('mistake');
    // Finer-grained pattern tags (hanging piece, back rank, etc.) require
    // tactical pattern detection on the board — implemented in Phase 3's
    // "Learn From My Mistakes" engine, which reuses these MoveAnalysis
    // records plus a board-state scan.
    return tags;
  }

  String _explain(MoveClassification c, String played, String best) {
    switch (c) {
      case MoveClassification.brilliant:
        return 'A hard-to-find move that turns the position sharply in your favor.';
      case MoveClassification.best:
        return 'The strongest move available in this position.';
      case MoveClassification.excellent:
        return 'Very close to the best move — kept your position intact.';
      case MoveClassification.good:
        return 'A solid, reasonable move.';
      case MoveClassification.book:
        return 'Known opening theory.';
      case MoveClassification.inaccuracy:
        return '$best was more precise than $played.';
      case MoveClassification.mistake:
        return '$best kept a clear advantage; $played let it slip.';
      case MoveClassification.missedWin:
        return 'You had a winning advantage here — $best kept it, $played gave it back.';
      case MoveClassification.blunder:
        return '$best was necessary. $played loses significant material or the game.';
    }
  }

  String _uciToSan(chesslib.Chess position, String uci) {
    if (uci.length < 4 || uci == '0000') return uci;
    final from = uci.substring(0, 2);
    final to = uci.substring(2, 4);
    final promotion = uci.length > 4 ? uci.substring(4, 5) : null;
    return sanForUciMove(position, from, to, promotion: promotion) ?? uci;
  }

  List<String> _pvToSan(chesslib.Chess position, List<String> uciMoves) {
    final clone = chesslib.Chess.fromFEN(position.fen);
    final sans = <String>[];
    for (final uci in uciMoves) {
      if (uci.length < 4) break;
      final from = uci.substring(0, 2);
      final to = uci.substring(2, 4);
      final promotion = uci.length > 4 ? uci.substring(4, 5) : null;
      final san = sanForUciMove(clone, from, to, promotion: promotion);
      if (san == null) break;
      final ok = clone.move({
        'from': from,
        'to': to,
        if (promotion != null) 'promotion': promotion,
      });
      if (!ok) break;
      sans.add(san);
    }
    return sans;
  }
}
