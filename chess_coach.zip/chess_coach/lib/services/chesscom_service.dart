import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/chess_game.dart';
import 'pgn_parser.dart';

class ChessComException implements Exception {
  final String message;
  ChessComException(this.message);
  @override
  String toString() => message;
}

/// Chess.com's public API (https://www.chess.com/news/view/published-data-api)
/// requires no authentication and no password for reading a player's own
/// public games — it's just their username. There is no official
/// "connect your account" OAuth flow for personal Chess.com data, so this
/// is the correct, fully-automatic integration; nothing here needs a
/// developer-obtained credential.
class ChessComService {
  final http.Client _client;
  ChessComService({http.Client? client}) : _client = client ?? http.Client();

  static const _base = 'https://api.chess.com/pub';

  /// Chess.com groups games by monthly archive. Returns archive URLs, most
  /// recent first.
  Future<List<String>> getArchiveUrls(String username) async {
    final res = await _client
        .get(Uri.parse('$_base/player/${Uri.encodeComponent(username.toLowerCase())}/games/archives'))
        .timeout(const Duration(seconds: 15));

    if (res.statusCode == 404) {
      throw ChessComException('No Chess.com account found for "$username".');
    }
    if (res.statusCode != 200) {
      throw ChessComException('Chess.com API returned ${res.statusCode}.');
    }

    final json = jsonDecode(res.body) as Map<String, dynamic>;
    final archives = (json['archives'] as List).map((e) => e.toString()).toList();
    return archives.reversed.toList(); // most recent month first
  }

  /// Fetches and parses games from a single monthly archive URL.
  Future<List<ChessGame>> getGamesFromArchive(String archiveUrl) async {
    final res = await _client.get(Uri.parse(archiveUrl)).timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw ChessComException('Failed to fetch archive (${res.statusCode}).');
    }
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    final games = (json['games'] as List? ?? []);
    final results = <ChessGame>[];
    for (final g in games) {
      final pgn = g['pgn'] as String?;
      if (pgn == null) continue;
      try {
        results.add(PgnParser.parseSingle(pgn, source: GameSource.chessCom));
      } catch (_) {
        // Skip any single malformed game rather than aborting the whole sync.
      }
    }
    return results;
  }

  /// Convenience: most recent N games across the newest archives, without
  /// pulling a user's entire multi-year history on first sync.
  Future<List<ChessGame>> getRecentGames(String username, {int maxGames = 20}) async {
    final archives = await getArchiveUrls(username);
    final results = <ChessGame>[];
    for (final url in archives) {
      if (results.length >= maxGames) break;
      final games = await getGamesFromArchive(url);
      results.addAll(games.reversed); // newest within the month first
    }
    return results.take(maxGames).toList();
  }

  void dispose() => _client.close();
}
