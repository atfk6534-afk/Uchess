import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/move_analysis.dart';
import 'app_config.dart';

class CloudAnalysisUnavailable implements Exception {
  final String reason;
  CloudAnalysisUnavailable(this.reason);
  @override
  String toString() => 'CloudAnalysisUnavailable: $reason';
}

/// Talks to the `server/` API built alongside this app. Mirrors the exact
/// response shape returned by `POST /api/analyze` (see server/README.md).
class CloudAnalysisService {
  final http.Client _client;
  final Duration timeout;

  CloudAnalysisService({http.Client? client, this.timeout = const Duration(seconds: 20)})
      : _client = client ?? http.Client();

  Future<bool> isHealthy() async {
    if (!AppConfig.hasCloudServerConfigured) return false;
    try {
      final res = await _client
          .get(Uri.parse('${AppConfig.analysisServerUrl}/api/health'))
          .timeout(const Duration(seconds: 5));
      if (res.statusCode != 200) return false;
      final body = jsonDecode(res.body);
      return body['status'] == 'ok';
    } catch (_) {
      return false;
    }
  }

  Future<EngineAnalysisResult> analyzeFen(
    String fen, {
    int depth = 18,
    int multipv = 1,
  }) async {
    if (!AppConfig.hasCloudServerConfigured) {
      throw CloudAnalysisUnavailable('No cloud analysis server is configured.');
    }
    final uri = Uri.parse('${AppConfig.analysisServerUrl}/api/analyze');
    try {
      final res = await _client
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'fen': fen, 'depth': depth, 'multipv': multipv}),
          )
          .timeout(timeout);

      if (res.statusCode != 200) {
        final body = _tryDecode(res.body);
        throw CloudAnalysisUnavailable(
            body?['error']?.toString() ?? 'Server returned ${res.statusCode}.');
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;
      return EngineAnalysisResult(
        evaluation: Evaluation(
          centipawns: json['evaluation'] != null
              ? ((json['evaluation'] as num) * 100).round()
              : null,
          mateIn: json['mate'] as int?,
          depth: json['depth'] as int? ?? 0,
        ),
        bestMoveUci: json['bestMove'] as String? ?? '0000',
        principalVariationUci:
            (json['principalVariation'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
    } on CloudAnalysisUnavailable {
      rethrow;
    } catch (e) {
      throw CloudAnalysisUnavailable('Could not reach the analysis server: $e');
    }
  }

  Map<String, dynamic>? _tryDecode(String body) {
    try {
      return jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  void dispose() => _client.close();
}

class EngineAnalysisResult {
  final Evaluation evaluation;
  final String bestMoveUci;
  final List<String> principalVariationUci;

  EngineAnalysisResult({
    required this.evaluation,
    required this.bestMoveUci,
    required this.principalVariationUci,
  });
}
