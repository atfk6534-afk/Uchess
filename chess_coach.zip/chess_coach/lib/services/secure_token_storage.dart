import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Thin wrapper so the rest of the app never touches
/// FlutterSecureStorage directly, and so there's exactly one place that
/// could leak a token into logs if someone made a mistake — making it easy
/// to audit. Only OAuth access/refresh tokens are ever stored here; this
/// app never asks for or stores a Chess.com/Lichess password.
class SecureTokenStorage {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _lichessAccessTokenKey = 'lichess_access_token';
  static const _lichessRefreshTokenKey = 'lichess_refresh_token';

  static Future<void> saveLichessTokens({
    required String accessToken,
    String? refreshToken,
  }) async {
    await _storage.write(key: _lichessAccessTokenKey, value: accessToken);
    if (refreshToken != null) {
      await _storage.write(key: _lichessRefreshTokenKey, value: refreshToken);
    }
  }

  static Future<String?> getLichessAccessToken() =>
      _storage.read(key: _lichessAccessTokenKey);

  static Future<String?> getLichessRefreshToken() =>
      _storage.read(key: _lichessRefreshTokenKey);

  static Future<void> clearLichessTokens() async {
    await _storage.delete(key: _lichessAccessTokenKey);
    await _storage.delete(key: _lichessRefreshTokenKey);
  }

  static Future<bool> get isLichessConnected async =>
      (await getLichessAccessToken()) != null;
}
