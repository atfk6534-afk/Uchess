import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../models/chess_game.dart';
import 'app_config.dart';
import 'pgn_parser.dart';
import 'secure_token_storage.dart';

class LichessNotConfiguredException implements Exception {
  @override
  String toString() =>
      'Lichess isn\'t configured yet. See README.md > "One-time setup" for '
      'the 5-minute step to register a free OAuth client id at lichess.org.';
}

class LichessException implements Exception {
  final String message;
  LichessException(this.message);
  @override
  String toString() => message;
}

/// Lichess's OAuth2 flow uses PKCE and, unlike most OAuth providers,
/// genuinely requires **no client secret** for public/mobile clients — see
/// https://lichess.org/api#tag/OAuth. What it does require is a client id
/// that's tied to *your* Lichess account and a redirect URI you control,
/// which only you can create (Claude/Anthropic can't register this for
/// you). That one-time step is documented in the top-level README.
///
/// This class never asks for or stores a Lichess password — only the OAuth
/// access token, and only in secure storage.
class LichessService {
  final http.Client _client;
  LichessService({http.Client? client}) : _client = client ?? http.Client();

  static const _authBase = 'https://lichess.org';

  String? _pendingCodeVerifier;

  /// Step 1 of the OAuth flow: opens the Lichess consent page in the
  /// system browser. The redirect back into the app (via the
  /// `LICHESS_REDIRECT_URI` deep link / custom scheme registered in
  /// AndroidManifest.xml) must be captured by app-level deep-link handling
  /// and passed to [completeAuth].
  Future<void> startAuth() async {
    if (!AppConfig.hasLichessConfigured) {
      throw LichessNotConfiguredException();
    }

    final verifier = _randomUrlSafeString(64);
    _pendingCodeVerifier = verifier;
    final challenge = base64UrlEncode(sha256.convert(utf8.encode(verifier)).bytes)
        .replaceAll('=', '');

    final authUrl = Uri.parse('$_authBase/oauth').replace(queryParameters: {
      'response_type': 'code',
      'client_id': AppConfig.lichessClientId,
      'redirect_uri': AppConfig.lichessRedirectUri,
      'code_challenge_method': 'S256',
      'code_challenge': challenge,
      'scope': 'preference:read',
    });

    final launched = await launchUrl(authUrl, mode: LaunchMode.externalApplication);
    if (!launched) {
      throw LichessException('Could not open the Lichess sign-in page.');
    }
  }

  /// Step 2: call this once your deep-link handler receives the redirect
  /// URI with a `?code=...` query parameter.
  Future<void> completeAuth(String redirectedUri) async {
    final verifier = _pendingCodeVerifier;
    if (verifier == null) {
      throw LichessException('No auth flow in progress. Call startAuth() first.');
    }
    final code = Uri.parse(redirectedUri).queryParameters['code'];
    if (code == null) {
      throw LichessException('Lichess redirect did not include an authorization code.');
    }

    final res = await _client.post(
      Uri.parse('$_authBase/api/token'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'grant_type': 'authorization_code',
        'code': code,
        'code_verifier': verifier,
        'redirect_uri': AppConfig.lichessRedirectUri,
        'client_id': AppConfig.lichessClientId,
      }),
    );

    if (res.statusCode != 200) {
      throw LichessException('Lichess token exchange failed (${res.statusCode}).');
    }

    final json = jsonDecode(res.body) as Map<String, dynamic>;
    await SecureTokenStorage.saveLichessTokens(
      accessToken: json['access_token'] as String,
      refreshToken: json['refresh_token'] as String?,
    );
    _pendingCodeVerifier = null;
  }

  Future<bool> get isConnected => SecureTokenStorage.isLichessConnected;

  Future<void> disconnect() => SecureTokenStorage.clearLichessTokens();

  /// Fetches the signed-in user's recent games as PGN (newline-delimited
  /// PGN stream — Lichess's native export format) and parses them.
  Future<List<ChessGame>> getRecentGames({int maxGames = 20}) async {
    final token = await SecureTokenStorage.getLichessAccessToken();
    if (token == null) {
      throw LichessException('Not connected to Lichess yet.');
    }

    final exportUri = Uri.parse('$_authBase/api/games/user/me').replace(queryParameters: {
      'max': maxGames.toString(),
      'pgnInJson': 'false',
    });

    final res = await _client.get(
      exportUri,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/x-chess-pgn'},
    );

    if (res.statusCode == 401) {
      throw LichessException('Lichess session expired — please reconnect your account.');
    }
    if (res.statusCode != 200) {
      throw LichessException('Lichess API returned ${res.statusCode}.');
    }

    return PgnParser.parseMultiple(res.body, source: GameSource.lichess);
  }

  String _randomUrlSafeString(int length) {
    final rand = Random.secure();
    final bytes = List<int>.generate(length, (_) => rand.nextInt(256));
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  void dispose() => _client.close();
}
