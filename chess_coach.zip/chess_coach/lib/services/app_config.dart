/// Central place the app reads its cloud analysis server URL from.
///
/// Zero-configuration by default: if you don't set anything, the app works
/// entirely offline using local Stockfish. To use cloud analysis, either:
///
///   1. Pass it at build time (no code edits needed):
///      flutter build apk --release --dart-define=ANALYSIS_SERVER_URL=https://your-server.example.com
///
///   2. Or edit the fallback default below once, after you deploy `server/`.
class AppConfig {
  static const String _buildTimeServerUrl =
      String.fromEnvironment('ANALYSIS_SERVER_URL', defaultValue: '');

  /// Empty string means "no cloud server configured" — the app should
  /// silently behave as Offline-only in that case, never crash or nag.
  static String get analysisServerUrl {
    if (_buildTimeServerUrl.isNotEmpty) return _buildTimeServerUrl;
    return _defaultServerUrl;
  }

  static bool get hasCloudServerConfigured => analysisServerUrl.isNotEmpty;

  /// Placeholder — intentionally empty. Fill this in only if you'd rather
  /// bake the URL into the app than pass --dart-define every build.
  static const String _defaultServerUrl = '';

  /// Lichess OAuth client id. Lichess requires an app to register a client
  /// id (no client secret needed — it uses PKCE). This has to be created
  /// once by you at https://lichess.org/api/app — Anthropic/Claude cannot
  /// generate this on your behalf since it's tied to your Lichess account
  /// and a redirect URI you own.
  static const String lichessClientId =
      String.fromEnvironment('LICHESS_CLIENT_ID', defaultValue: '');

  static const String lichessRedirectUri = String.fromEnvironment(
    'LICHESS_REDIRECT_URI',
    defaultValue: 'chesscoach://lichess-callback',
  );

  static bool get hasLichessConfigured => lichessClientId.isNotEmpty;
}
