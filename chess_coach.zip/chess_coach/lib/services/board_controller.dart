import 'package:chess/chess.dart' as chesslib;
import 'package:flutter/foundation.dart';

import 'chess_notation_utils.dart';
import '../widgets/chess_board.dart';

/// Drives a [ChessBoardWidget] from either live play or move navigation
/// through an already-known game. Kept separate from analysis so it can
/// also be reused by the Practice / Training screens.
class BoardController extends ChangeNotifier {
  chesslib.Chess _position = chesslib.Chess();
  Square? _selected;
  Set<Square> _legalTargets = {};
  Square? lastMoveFrom;
  Square? lastMoveTo;
  bool flipped = false;

  chesslib.Chess get position => _position;
  Square? get selected => _selected;
  Set<Square> get legalTargets => _legalTargets;

  List<List<String?>> get boardGrid {
    // Build an 8x8 grid where row 0 = rank 8, matching ChessBoardWidget's
    // expected layout.
    final grid = List.generate(8, (_) => List<String?>.filled(8, null));
    for (var rank = 0; rank < 8; rank++) {
      for (var file = 0; file < 8; file++) {
        final square = _position.board[(7 - rank) * 16 + file];
        if (square != null) {
          final letter = square.type.toString();
          final isWhite = square.color == chesslib.Color.WHITE;
          grid[7 - rank][file] = isWhite ? letter.toUpperCase() : letter.toLowerCase();
        }
      }
    }
    return grid;
  }

  Square? get kingInCheck {
    if (!_position.in_check) return null;
    final color = _position.turn;
    for (var rank = 0; rank < 8; rank++) {
      for (var file = 0; file < 8; file++) {
        final sq = _position.board[rank * 16 + file];
        if (sq != null && sq.type == chesslib.PieceType.KING && sq.color == color) {
          return Square(file, rank);
        }
      }
    }
    return null;
  }

  void loadFen(String fen) {
    _position = chesslib.Chess.fromFEN(fen);
    _selected = null;
    _legalTargets = {};
    notifyListeners();
  }

  void loadStartPosition() {
    _position = chesslib.Chess();
    _selected = null;
    _legalTargets = {};
    lastMoveFrom = null;
    lastMoveTo = null;
    notifyListeners();
  }

  /// Handles a tap: selects a piece, or attempts a move if a piece is
  /// already selected. Returns the SAN of the move if one was made.
  String? handleTap(Square square) {
    if (_selected == null) {
      final piece = _position.get(square.name);
      if (piece != null && piece.color == _position.turn) {
        _selected = square;
        _legalTargets = _computeLegalTargets(square);
        notifyListeners();
      }
      return null;
    }

    if (_selected == square) {
      _selected = null;
      _legalTargets = {};
      notifyListeners();
      return null;
    }

    final from = _selected!;
    _selected = null;

    final sanBeforeMove = sanForUciMove(_position, from.name, square.name, promotion: 'q');
    final moved = _position.move({'from': from.name, 'to': square.name, 'promotion': 'q'});
    if (moved) {
      lastMoveFrom = from;
      lastMoveTo = square;
      _legalTargets = {};
      notifyListeners();
      return sanBeforeMove;
    }

    // Not a legal move for that piece — maybe selecting a different piece.
    final piece = _position.get(square.name);
    if (piece != null && piece.color == _position.turn) {
      _selected = square;
      _legalTargets = _computeLegalTargets(square);
    } else {
      _legalTargets = {};
    }
    notifyListeners();
    return null;
  }

  Set<Square> _computeLegalTargets(Square from) {
    final moves = _position.moves({'square': from.name, 'verbose': true});
    final targets = <Square>{};
    for (final m in moves) {
      final to = m['to'] as String?;
      if (to != null) targets.add(Square.fromName(to));
    }
    return targets;
  }

  void toggleFlip() {
    flipped = !flipped;
    notifyListeners();
  }
}
