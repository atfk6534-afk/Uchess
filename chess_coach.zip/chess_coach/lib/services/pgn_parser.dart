import 'package:chess/chess.dart' as chesslib;
import 'package:uuid/uuid.dart';

import '../models/chess_game.dart';

class PgnParseException implements Exception {
  final String message;
  PgnParseException(this.message);
  @override
  String toString() => 'PgnParseException: $message';
}

class PgnParser {
  static const _uuid = Uuid();

  /// Parses a single PGN game (headers + movetext) into a [ChessGame].
  /// Throws [PgnParseException] with a human-readable message on failure —
  /// callers should catch this and show it rather than crash.
  static ChessGame parseSingle(String pgn, {GameSource source = GameSource.pgnImport}) {
    final trimmed = pgn.trim();
    if (trimmed.isEmpty) {
      throw PgnParseException('The PGN text is empty.');
    }

    final game = chesslib.Chess();
    final loaded = game.load_pgn(trimmed);
    if (loaded == false) {
      throw PgnParseException(
          'This PGN could not be read. Check that it has valid moves and try again.');
    }

    final headers = game.header;

    DateTime? parsedDate;
    final dateStr = headers['Date'];
    if (dateStr != null && dateStr != '????.??.??') {
      try {
        final parts = dateStr.split('.');
        if (parts.length == 3) {
          parsedDate = DateTime(
            int.parse(parts[0]),
            int.tryParse(parts[1]) ?? 1,
            int.tryParse(parts[2]) ?? 1,
          );
        }
      } catch (_) {
        // Leave date null on any malformed value rather than crash.
      }
    }

    final tc = headers['TimeControl'] ?? '';
    final category = _classifyTimeControl(tc);

    return ChessGame(
      id: _uuid.v4(),
      pgn: trimmed,
      white: headers['White'] ?? 'White',
      black: headers['Black'] ?? 'Black',
      result: headers['Result'] ?? '*',
      date: parsedDate,
      eco: headers['ECO'],
      opening: headers['Opening'],
      timeControl: tc,
      timeControlCategory: category,
      whiteRating: int.tryParse(headers['WhiteElo'] ?? ''),
      blackRating: int.tryParse(headers['BlackElo'] ?? ''),
      source: source,
    );
  }

  /// A PGN file / pasted blob can contain multiple games back to back.
  /// Splits on blank-line-separated `[Event ...]` blocks.
  static List<ChessGame> parseMultiple(String pgnText,
      {GameSource source = GameSource.pgnImport}) {
    final blocks = <String>[];
    final lines = pgnText.split('\n');
    StringBuffer current = StringBuffer();
    for (final line in lines) {
      if (line.trimLeft().startsWith('[Event ') && current.toString().trim().isNotEmpty) {
        blocks.add(current.toString());
        current = StringBuffer();
      }
      current.writeln(line);
    }
    if (current.toString().trim().isNotEmpty) {
      blocks.add(current.toString());
    }

    final results = <ChessGame>[];
    final errors = <String>[];
    for (var i = 0; i < blocks.length; i++) {
      try {
        results.add(parseSingle(blocks[i], source: source));
      } catch (e) {
        errors.add('Game ${i + 1}: $e');
      }
    }
    if (results.isEmpty && errors.isNotEmpty) {
      throw PgnParseException(errors.join('\n'));
    }
    return results;
  }

  /// Returns the list of SAN moves in order (e.g. ["e4", "e5", "Nf3", ...]).
  static List<String> sanMoves(String pgn) {
    final game = chesslib.Chess();
    final ok = game.load_pgn(pgn);
    if (ok == false) {
      throw PgnParseException('Could not read moves from this PGN.');
    }
    return game.history.map((h) => h.move.san as String).toList();
  }

  /// Replays a game move by move and returns the FEN *after* each ply,
  /// including the starting position at index 0.
  static List<String> fenSequence(String pgn) {
    final replay = chesslib.Chess();
    final fens = <String>[replay.fen];
    final moves = sanMoves(pgn);
    for (final san in moves) {
      final ok = replay.move(san);
      if (ok == false) {
        throw PgnParseException('Illegal move "$san" found while replaying the game.');
      }
      fens.add(replay.fen);
    }
    return fens;
  }

  static TimeControlCategory _classifyTimeControl(String tc) {
    if (tc.isEmpty || tc == '-') return TimeControlCategory.unknown;
    // PGN TimeControl is usually "seconds+increment", e.g. "180+2".
    final base = int.tryParse(tc.split('+').first);
    if (base == null) return TimeControlCategory.unknown;
    if (base < 180) return TimeControlCategory.bullet;
    if (base < 600) return TimeControlCategory.blitz;
    if (base < 1800) return TimeControlCategory.rapid;
    return TimeControlCategory.classical;
  }
}
