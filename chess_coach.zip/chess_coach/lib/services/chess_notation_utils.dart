import 'package:chess/chess.dart' as chesslib;

/// The `chess` package's internal `Move` objects (from `position.history`)
/// do NOT expose a `.san` getter — SAN text only comes from the *verbose*
/// move list returned by `Chess.moves({'verbose': true})`, same as
/// chess.js. This helper is the one place that looks it up, so every
/// caller gets consistent, correct behavior instead of each guessing at
/// the package's API.
String? sanForUciMove(
  chesslib.Chess position,
  String uciFrom,
  String uciTo, {
  String? promotion,
}) {
  final verboseMoves = position.moves({'square': uciFrom, 'verbose': true}) as List;
  Map? fallback;
  for (final entry in verboseMoves) {
    final map = entry as Map;
    if (map['to'] != uciTo) continue;
    if (promotion != null && map['promotion'] == promotion) {
      return map['san'] as String?;
    }
    fallback ??= map;
  }
  return fallback?['san'] as String?;
}
