import 'dart:async';

import 'package:stockfish/stockfish.dart';

import '../models/move_analysis.dart';

/// Result of one `go` command: best move plus the evaluation reached.
class EngineResult {
  final String bestMoveUci;
  final Evaluation evaluation;
  final List<String> principalVariationUci;

  EngineResult({
    required this.bestMoveUci,
    required this.evaluation,
    required this.principalVariationUci,
  });
}

/// Thin wrapper around the `stockfish` plugin that speaks UCI, exposes a
/// simple Future-based `analyzePosition` call, and never blocks the UI
/// thread (the plugin itself runs the engine in a native background
/// process; this class just marshals stdin/stdout).
class StockfishService {
  Stockfish? _engine;
  StreamSubscription<String>? _outputSub;

  int depth;
  int hashMb;
  int threads;

  StockfishService({this.depth = 16, this.hashMb = 64, this.threads = 2});

  bool _ready = false;
  bool get isReady => _ready;

  Future<void> init() async {
    if (_engine != null) return;
    _engine = Stockfish();

    // Wait for the engine process to report it's ready.
    final completer = Completer<void>();
    _outputSub = _engine!.stdout.listen((line) {
      if (!completer.isCompleted && line.contains('uciok')) {
        completer.complete();
      }
    });

    _engine!.state.addListener(() {
      if (_engine!.state.value == StockfishState.ready && !completer.isCompleted) {
        completer.complete();
      }
    });

    _send('uci');
    await completer.future.timeout(
      const Duration(seconds: 10),
      onTimeout: () => throw Exception('Stockfish engine failed to start.'),
    );

    _send('setoption name Hash value $hashMb');
    _send('setoption name Threads value $threads');
    _send('isready');
    _ready = true;
  }

  void _send(String command) {
    _engine?.stdin = command;
  }

  /// Reduces engine resource usage for low-end devices. Call this once
  /// after detecting low RAM / low core count instead of the defaults.
  void configureForLowEndDevice() {
    depth = 12;
    hashMb = 16;
    threads = 1;
    _send('setoption name Hash value $hashMb');
    _send('setoption name Threads value $threads');
  }

  /// Analyzes a single FEN position and resolves once `bestmove` is seen.
  /// [onInfo] is called for every intermediate `info` line so callers can
  /// show a live "Analyzing... depth 14" style indicator.
  Future<EngineResult> analyzePosition(
    String fen, {
    int? searchDepth,
    void Function(int depth, Evaluation eval)? onInfo,
  }) async {
    if (!_ready) {
      throw StateError('StockfishService.init() must be called first.');
    }

    final targetDepth = searchDepth ?? depth;
    final completer = Completer<EngineResult>();

    Evaluation? lastEval;
    List<String> lastPv = [];

    late StreamSubscription<String> sub;
    sub = _engine!.stdout.listen((line) {
      if (line.startsWith('info') && line.contains('score')) {
        final parsed = _parseInfoLine(line);
        if (parsed != null) {
          lastEval = parsed.$1;
          lastPv = parsed.$2;
          onInfo?.call(parsed.$1.depth, parsed.$1);
        }
      } else if (line.startsWith('bestmove')) {
        final parts = line.split(' ');
        final best = parts.length > 1 ? parts[1] : '0000';
        sub.cancel();
        if (!completer.isCompleted) {
          completer.complete(EngineResult(
            bestMoveUci: best,
            evaluation: lastEval ?? const Evaluation(centipawns: 0, depth: 0),
            principalVariationUci: lastPv,
          ));
        }
      }
    });

    _send('position fen $fen');
    _send('go depth $targetDepth');

    return completer.future.timeout(
      const Duration(seconds: 30),
      onTimeout: () {
        sub.cancel();
        _send('stop');
        throw TimeoutException('Stockfish did not respond in time for this position.');
      },
    );
  }

  /// Stops any in-progress search immediately (e.g. user cancels analysis).
  void stopAnalysis() {
    _send('stop');
  }

  /// Parses a UCI `info ... score cp X / mate Y ... pv ...` line.
  /// Returns (evaluation, principal variation moves) or null if unparsable.
  (Evaluation, List<String>)? _parseInfoLine(String line) {
    final tokens = line.split(' ');
    int? depthVal;
    int? cp;
    int? mate;
    List<String> pv = [];

    for (var i = 0; i < tokens.length; i++) {
      switch (tokens[i]) {
        case 'depth':
          depthVal = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'cp':
          cp = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'mate':
          mate = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'pv':
          pv = tokens.sublist(i + 1);
          i = tokens.length;
          break;
      }
    }

    if (depthVal == null || (cp == null && mate == null)) return null;
    return (
      Evaluation(centipawns: cp, mateIn: mate, depth: depthVal),
      pv,
    );
  }

  Future<void> dispose() async {
    _outputSub?.cancel();
    _send('quit');
    _engine?.dispose();
    _engine = null;
    _ready = false;
  }
}
