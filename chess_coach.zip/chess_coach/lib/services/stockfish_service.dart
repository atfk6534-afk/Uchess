import 'dart:async';

import 'package:stockfish/stockfish.dart';

import '../models/move_analysis.dart';

/// Result of one `go` command: best move plus the evaluation reached.
class EngineResult {
  final String bestMoveUci;
  final Evaluation evaluation;
  final List<String> principalVariationUci;

  EngineResult({
    required this.bestMoveUci,
    required this.evaluation,
    required this.principalVariationUci,
  });
}

/// Thrown when the caller tries to start a new analysis while one is
/// already running. The UI should catch this and show
/// "التحليل جارٍ بالفعل" rather than treat it as a real failure.
class AnalysisAlreadyRunningException implements Exception {
  @override
  String toString() => 'AnalysisAlreadyRunningException';
}

enum EngineLifecycleState { uninitialized, initializing, ready, analyzing, disposed }

/// ROOT CAUSE OF "Bad state: Multiple instances are not supported, yet.":
///
/// The `stockfish` plugin is only designed to have its `Stockfish()`
/// constructor called ONCE for the entire lifetime of the app process —
/// the native/worker side is a true process-wide singleton, and calling
/// the constructor a second time (even after disposing the first
/// instance) throws that exact error. The previous version of this class
/// was constructed fresh (`StockfishService(...)`) every time a game
/// screen opened and the user pressed Analyze, so opening a second game
/// — or even re-analyzing the same one — reliably crashed.
///
/// The fix: this class is now a true singleton (`StockfishService.instance`).
/// `Stockfish()` is constructed exactly once, lazily, on first use, and is
/// never disposed during normal app navigation — every screen that needs
/// local analysis shares the same engine and the same request queue, so
/// concurrent `analyzePosition` calls from different screens can never
/// interleave UCI commands on the same stdin.
class StockfishService {
  StockfishService._internal();
  static final StockfishService instance = StockfishService._internal();

  Stockfish? _engine;
  StreamSubscription<String>? _outputSub;
  Future<void>? _initFuture;

  int depth = 16;
  int hashMb = 64;
  int threads = 2;

  EngineLifecycleState _state = EngineLifecycleState.uninitialized;
  EngineLifecycleState get state => _state;
  bool get isReady =>
      _state == EngineLifecycleState.ready || _state == EngineLifecycleState.analyzing;
  bool get isAnalyzing => _state == EngineLifecycleState.analyzing;

  // Serializes analyzePosition calls so two callers can never send
  // overlapping UCI commands to the single shared engine process.
  Future<void> _requestLock = Future.value();

  /// Idempotent: safe to call from every screen that needs the engine.
  /// The first call does the real work; concurrent/later calls just await
  /// the same in-flight (or already-completed) initialization.
  Future<void> init() {
    if (_state == EngineLifecycleState.ready ||
        _state == EngineLifecycleState.analyzing) {
      return Future.value();
    }
    if (_initFuture != null) {
      return _initFuture!;
    }
    _initFuture = _doInit();
    return _initFuture!;
  }

  Future<void> _doInit() async {
    _state = EngineLifecycleState.initializing;
    _engine = Stockfish();

    final completer = Completer<void>();
    _outputSub = _engine!.stdout.listen((line) {
      if (!completer.isCompleted && line.contains('uciok')) {
        completer.complete();
      }
    });

    void stateListener() {
      if (_engine!.state.value == StockfishState.ready && !completer.isCompleted) {
        completer.complete();
      }
    }

    _engine!.state.addListener(stateListener);

    _send('uci');
    try {
      await completer.future.timeout(
        const Duration(seconds: 10),
        onTimeout: () => throw Exception('Stockfish engine failed to start.'),
      );
    } catch (e) {
      _state = EngineLifecycleState.uninitialized;
      _initFuture = null;
      rethrow;
    }

    _send('setoption name Hash value $hashMb');
    _send('setoption name Threads value $threads');
    _send('isready');
    _state = EngineLifecycleState.ready;
  }

  void _send(String command) {
    _engine?.stdin = command;
  }

  /// Reduces engine resource usage for low-end devices. Call this once
  /// after detecting low RAM / low core count instead of the defaults.
  void configureForLowEndDevice() {
    depth = 12;
    hashMb = 16;
    threads = 1;
    if (isReady) {
      _send('setoption name Hash value $hashMb');
      _send('setoption name Threads value $threads');
    }
  }

  /// Analyzes a single FEN position and resolves once `bestmove` is seen.
  /// Calls are serialized against every other caller sharing this
  /// singleton, so two screens analyzing at "the same time" simply queue
  /// rather than corrupting each other's UCI exchange.
  Future<EngineResult> analyzePosition(
    String fen, {
    int? searchDepth,
    void Function(int depth, Evaluation eval)? onInfo,
  }) {
    final previous = _requestLock;
    final completer = Completer<EngineResult>();
    _requestLock = completer.future.catchError((_) {});

    previous.whenComplete(() async {
      try {
        final result = await _analyzePositionExclusive(
          fen,
          searchDepth: searchDepth,
          onInfo: onInfo,
        );
        completer.complete(result);
      } catch (e, st) {
        completer.completeError(e, st);
      }
    });

    return completer.future;
  }

  Future<EngineResult> _analyzePositionExclusive(
    String fen, {
    int? searchDepth,
    void Function(int depth, Evaluation eval)? onInfo,
  }) async {
    if (!isReady) {
      throw StateError('StockfishService.init() must complete before analyzing.');
    }

    _state = EngineLifecycleState.analyzing;
    final targetDepth = searchDepth ?? depth;
    final resultCompleter = Completer<EngineResult>();

    Evaluation? lastEval;
    List<String> lastPv = [];

    late StreamSubscription<String> sub;
    sub = _engine!.stdout.listen((line) {
      if (line.startsWith('info') && line.contains('score')) {
        final parsed = _parseInfoLine(line);
        if (parsed != null) {
          lastEval = parsed.$1;
          lastPv = parsed.$2;
          onInfo?.call(parsed.$1.depth, parsed.$1);
        }
      } else if (line.startsWith('bestmove')) {
        final parts = line.split(' ');
        final best = parts.length > 1 ? parts[1] : '0000';
        sub.cancel();
        if (!resultCompleter.isCompleted) {
          resultCompleter.complete(EngineResult(
            bestMoveUci: best,
            evaluation: lastEval ?? const Evaluation(centipawns: 0, depth: 0),
            principalVariationUci: lastPv,
          ));
        }
      }
    });

    _send('position fen $fen');
    _send('go depth $targetDepth');

    try {
      final result = await resultCompleter.future.timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          sub.cancel();
          _send('stop');
          throw TimeoutException('Stockfish did not respond in time for this position.');
        },
      );
      _state = EngineLifecycleState.ready;
      return result;
    } catch (e) {
      _state = EngineLifecycleState.ready;
      rethrow;
    }
  }

  /// Stops any in-progress search immediately (e.g. user cancels analysis).
  /// The engine itself is NOT disposed — it stays ready for the next
  /// request, since disposing/recreating is exactly what caused the
  /// original crash.
  void stopAnalysis() {
    if (isAnalyzing) {
      _send('stop');
    }
  }

  (Evaluation, List<String>)? _parseInfoLine(String line) {
    final tokens = line.split(' ');
    int? depthVal;
    int? cp;
    int? mate;
    List<String> pv = [];

    for (var i = 0; i < tokens.length; i++) {
      switch (tokens[i]) {
        case 'depth':
          depthVal = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'cp':
          cp = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'mate':
          mate = int.tryParse(tokens.length > i + 1 ? tokens[i + 1] : '');
          break;
        case 'pv':
          pv = tokens.sublist(i + 1);
          i = tokens.length;
          break;
      }
    }

    if (depthVal == null || (cp == null && mate == null)) return null;
    return (
      Evaluation(centipawns: cp, mateIn: mate, depth: depthVal),
      pv,
    );
  }

  /// Intentionally does NOT tear down the underlying Stockfish() instance.
  /// The plugin does not support recreating it, so the shared singleton
  /// lives for the app's whole process lifetime. This only cancels the
  /// output listener, which is safe to redo on next init() if ever needed.
  Future<void> disposeListenerOnly() async {
    await _outputSub?.cancel();
  }
}
