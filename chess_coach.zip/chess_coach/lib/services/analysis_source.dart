import 'cloud_analysis_service.dart';
import 'stockfish_service.dart';
import '../models/move_analysis.dart';

enum AnalysisMode { cloud, offline, auto }

/// Wraps whichever engine actually served a given request, so the UI can
/// show "Analyzed via Cloud" / "Analyzed via Local engine" honestly instead
/// of assuming.
class AnalysisSourceResult {
  final Evaluation evaluation;
  final String bestMoveUci;
  final List<String> principalVariationUci;
  final bool wasCloud;

  AnalysisSourceResult({
    required this.evaluation,
    required this.bestMoveUci,
    required this.principalVariationUci,
    required this.wasCloud,
  });
}

/// Single entry point the rest of the app calls to analyze a position,
/// regardless of which mode the user picked in Settings. Local Stockfish
/// must be initialized by the caller first (it needs an async `init()`);
/// this class doesn't own that lifecycle since the local engine is also
/// used standalone by the Game Viewer in Phase 1.
class AnalysisSource {
  final CloudAnalysisService cloud;
  final StockfishService local;
  AnalysisMode mode;

  AnalysisSource({
    required this.local,
    CloudAnalysisService? cloud,
    this.mode = AnalysisMode.auto,
  }) : cloud = cloud ?? CloudAnalysisService();

  Future<AnalysisSourceResult> analyze(
    String fen, {
    int depth = 16,
    int multipv = 1,
  }) async {
    switch (mode) {
      case AnalysisMode.offline:
        return _local(fen, depth);

      case AnalysisMode.cloud:
        // Explicit Cloud mode: don't silently fall back — the user asked
        // for cloud specifically (e.g. to save battery). Surface the error.
        final result = await cloud.analyzeFen(fen, depth: depth, multipv: multipv);
        return AnalysisSourceResult(
          evaluation: result.evaluation,
          bestMoveUci: result.bestMoveUci,
          principalVariationUci: result.principalVariationUci,
          wasCloud: true,
        );

      case AnalysisMode.auto:
        try {
          final result = await cloud.analyzeFen(fen, depth: depth, multipv: multipv);
          return AnalysisSourceResult(
            evaluation: result.evaluation,
            bestMoveUci: result.bestMoveUci,
            principalVariationUci: result.principalVariationUci,
            wasCloud: true,
          );
        } catch (_) {
          return _local(fen, depth);
        }
    }
  }

  Future<AnalysisSourceResult> _local(String fen, int depth) async {
    final result = await local.analyzePosition(fen, searchDepth: depth);
    return AnalysisSourceResult(
      evaluation: result.evaluation,
      bestMoveUci: result.bestMoveUci,
      principalVariationUci: result.principalVariationUci,
      wasCloud: false,
    );
  }
}
