import 'package:flutter_test/flutter_test.dart';
import 'package:chess_coach/services/pgn_parser.dart';
import 'package:chess_coach/models/chess_game.dart';

const samplePgn = '''
[Event "Live Chess"]
[Site "Chess.com"]
[Date "2026.01.15"]
[White "PlayerOne"]
[Black "PlayerTwo"]
[Result "1-0"]
[ECO "C50"]
[WhiteElo "1500"]
[BlackElo "1480"]
[TimeControl "600"]

1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. O-O O-O 1-0
''';

const malformedPgn = 'this is not a pgn at all';

void main() {
  group('PgnParser.parseSingle', () {
    test('extracts headers correctly', () {
      final game = PgnParser.parseSingle(samplePgn);
      expect(game.white, 'PlayerOne');
      expect(game.black, 'PlayerTwo');
      expect(game.result, '1-0');
      expect(game.eco, 'C50');
      expect(game.whiteRating, 1500);
      expect(game.blackRating, 1480);
      expect(game.date, DateTime(2026, 1, 15));
    });

    test('classifies time control as rapid for 600 seconds base', () {
      final game = PgnParser.parseSingle(samplePgn);
      expect(game.timeControlCategory, TimeControlCategory.rapid);
    });

    test('throws PgnParseException on empty input', () {
      expect(() => PgnParser.parseSingle(''), throwsA(isA<PgnParseException>()));
    });

    test('throws PgnParseException on malformed input', () {
      expect(() => PgnParser.parseSingle(malformedPgn), throwsA(isA<PgnParseException>()));
    });
  });

  group('PgnParser.sanMoves', () {
    test('extracts the correct move list', () {
      final moves = PgnParser.sanMoves(samplePgn);
      expect(moves, [
        'e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'c3', 'Nf6', 'd3', 'd6', 'O-O', 'O-O'
      ]);
    });
  });

  group('PgnParser.fenSequence', () {
    test('returns one more FEN than the number of moves (includes start position)', () {
      final moves = PgnParser.sanMoves(samplePgn);
      final fens = PgnParser.fenSequence(samplePgn);
      expect(fens.length, moves.length + 1);
    });

    test('first FEN is the standard starting position', () {
      final fens = PgnParser.fenSequence(samplePgn);
      expect(fens.first, startsWith('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq'));
    });
  });

  group('PgnParser.parseMultiple', () {
    test('parses two back-to-back games from one blob', () {
      final blob = '$samplePgn\n\n$samplePgn';
      final games = PgnParser.parseMultiple(blob);
      expect(games.length, 2);
    });

    test('skips a malformed game among valid ones rather than failing entirely', () {
      final blob = '$samplePgn\n\n[Event "Bad"]\n1. zz9 garbage';
      final games = PgnParser.parseMultiple(blob);
      expect(games.length, 1);
    });
  });

  group('Time control classification', () {
    ChessGame withTc(String tc) => PgnParser.parseSingle(
        samplePgn.replaceFirst('[TimeControl "600"]', '[TimeControl "$tc"]'));

    test('bullet for base < 180s', () {
      expect(withTc('60').timeControlCategory, TimeControlCategory.bullet);
    });
    test('blitz for base 180-599s', () {
      expect(withTc('300').timeControlCategory, TimeControlCategory.blitz);
    });
    test('rapid for base 600-1799s', () {
      expect(withTc('900').timeControlCategory, TimeControlCategory.rapid);
    });
    test('classical for base >= 1800s', () {
      expect(withTc('3600').timeControlCategory, TimeControlCategory.classical);
    });
  });
}
