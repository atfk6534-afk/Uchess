import 'package:flutter_test/flutter_test.dart';
import 'package:chess_coach/models/move_analysis.dart';
import 'package:chess_coach/models/chess_game.dart';

void main() {
  group('Evaluation', () {
    test('display formats positive centipawns with a plus sign', () {
      const eval = Evaluation(centipawns: 142, depth: 20);
      expect(eval.display, '+1.42');
    });

    test('display formats negative centipawns without a double sign', () {
      const eval = Evaluation(centipawns: -85, depth: 20);
      expect(eval.display, '-0.85');
    });

    test('display formats mate scores as M<n>', () {
      const eval = Evaluation(mateIn: 3, depth: 20);
      expect(eval.display, 'M3');
    });

    test('isMate is true only when mateIn is set', () {
      expect(const Evaluation(mateIn: 2, depth: 10).isMate, isTrue);
      expect(const Evaluation(centipawns: 10, depth: 10).isMate, isFalse);
    });

    test('score places mate scores beyond normal centipawn range', () {
      const winningMate = Evaluation(mateIn: 1, depth: 10);
      const bigCpAdvantage = Evaluation(centipawns: 900, depth: 10);
      expect(winningMate.score, greaterThan(bigCpAdvantage.score));
    });

    test('toJson/fromJson round-trip preserves values', () {
      const original = Evaluation(centipawns: 55, mateIn: null, depth: 18);
      final restored = Evaluation.fromJson(original.toJson());
      expect(restored.centipawns, original.centipawns);
      expect(restored.depth, original.depth);
    });
  });

  group('MoveAnalysis.evalLossForMover', () {
    MoveAnalysis makeMove({
      required String fenBefore,
      required Evaluation before,
      required Evaluation after,
    }) {
      return MoveAnalysis(
        plyNumber: 1,
        sanMove: 'e4',
        fenBefore: fenBefore,
        fenAfter: fenBefore,
        evalBefore: before,
        evalAfter: after,
        bestMoveSan: 'e4',
        principalVariation: 'e4 e5',
        classification: MoveClassification.good,
      );
    }

    test('positive loss when White throws away an advantage', () {
      final move = makeMove(
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        before: const Evaluation(centipawns: 200, depth: 15),
        after: const Evaluation(centipawns: 0, depth: 15),
      );
      expect(move.evalLossForMover, closeTo(200, 0.01));
    });

    test('positive loss when Black throws away an advantage (score sign flips for mover)', () {
      final move = makeMove(
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1',
        before: const Evaluation(centipawns: -200, depth: 15), // good for Black
        after: const Evaluation(centipawns: 0, depth: 15),
      );
      expect(move.evalLossForMover, closeTo(200, 0.01));
    });

    test('zero loss when eval is unchanged', () {
      final move = makeMove(
        fenBefore: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        before: const Evaluation(centipawns: 30, depth: 15),
        after: const Evaluation(centipawns: 30, depth: 15),
      );
      expect(move.evalLossForMover, closeTo(0, 0.01));
    });
  });

  group('MoveClassification labels', () {
    test('every classification has a non-empty label and symbol', () {
      for (final c in MoveClassification.values) {
        expect(c.label, isNotEmpty);
      }
    });
  });

  group('ChessGame.accuracyFor', () {
    test('returns 0 when the game has no analysis', () {
      final game = ChessGame(
        id: '1',
        pgn: '1. e4 e5',
        white: 'A',
        black: 'B',
        result: '1-0',
      );
      expect(game.accuracyFor(true), 0);
    });

    test('perfect play (no eval loss) yields a high accuracy score', () {
      final moves = List.generate(
        6,
        (i) => MoveAnalysis(
          plyNumber: i + 1,
          sanMove: 'e4',
          fenBefore: i.isEven
              ? 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
              : 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1',
          fenAfter: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          evalBefore: const Evaluation(centipawns: 20, depth: 15),
          evalAfter: const Evaluation(centipawns: 20, depth: 15),
          bestMoveSan: 'e4',
          principalVariation: 'e4',
          classification: MoveClassification.best,
        ),
      );
      final game = ChessGame(
        id: '1',
        pgn: '1. e4 e5',
        white: 'A',
        black: 'B',
        result: '1-0',
        analysis: moves,
      );
      expect(game.accuracyFor(true), greaterThan(95));
    });
  });
}
