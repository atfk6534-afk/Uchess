# Flutter's own embedding classes talk to native code via JNI and platform
# channels; R8 can't see those call paths statically, so keep them intact.
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# The stockfish plugin bridges to a native process via platform channels;
# keep its method-channel handler classes so R8 doesn't rename/remove
# anything the native side expects to find by name.
-keep class com.github.xu.stockfish.** { *; }
-keep class com.stockfish.** { *; }

# Keep anything annotated as a Flutter plugin entrypoint.
-keepclassmembers class * {
    @io.flutter.plugin.common.MethodChannel.MethodCallHandler *;
}

# General Android/Kotlin safety nets that prevent common R8 false-positive
# strips in Flutter release builds.
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-dontwarn io.flutter.embedding.**
