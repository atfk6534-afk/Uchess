package com.chesscoach.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
