# Chess Coach

A personal chess coach app: Flutter Android client + a cloud Stockfish
analysis server, with local Stockfish as an automatic offline fallback.

```
Android Flutter App
        |
        | HTTPS (POST /api/analyze)
        v
Chess Analysis API  (server/, Node + Express)
        |
        v
Stockfish process pool (queued, crash-recovering)

Android app also carries local Stockfish for Offline mode / cloud fallback.
```

## What's genuinely verified vs. what isn't

I have a Node.js sandbox but **no Flutter/Android SDK and no Docker daemon**
in this environment. Here's exactly what that means for each piece:

| Piece | Status |
|---|---|
| `server/` (Node/Express/Stockfish) | ✅ **Actually run.** `npm install` (359 packages), `npm test` (25/25 passing, including a real-Stockfish integration suite), and the live HTTP server was booted and hit with real `curl` requests — health check, analyze, and validation errors all confirmed working. |
| `server/Dockerfile` | ⚠️ Written carefully (same Stockfish apt package/version the tests ran against), but `docker build` could not be run here — no Docker daemon available. `.github/workflows/server.yml` builds and smoke-tests it on every push; treat that first run as the real check. |
| Android app (`lib/`) | ⚠️ Written carefully, cross-checked for brace/paren balance and consistent imports across all 26 files, but **not compiled** — no Flutter SDK here, and `pub.dev` isn't reachable from this sandbox either way. `.github/workflows/android.yml` runs `flutter analyze --fatal-infos`, `flutter test`, and `flutter build apk --release` with no error-suppression — that first CI run is the genuine verification. |
| `test/*.dart` (Flutter unit tests) | ⚠️ Written to match the actual model/service APIs, but not run — same reason as above. |

I'm telling you this plainly because you explicitly asked for confirmed,
tested output — the server claim above is one I can actually stand behind
because I ran it. The Android claim I can't make with the same confidence,
and pretending otherwise would just cost you a debugging session down the
line instead of now.

**Practical effect:** push this to GitHub, watch both workflow runs. The
`server.yml` run has a good chance of going green on the first try. The
`android.yml` run is more likely to need one or two small fixes (a typo, a
package API mismatch) — send me the Actions log and I'll fix it directly.

## One-time setup steps (things only you can do)

1. **Nothing is required to get local/offline analysis working.** Import a
   PGN, hit Analyze — local Stockfish just works, no config.
2. **Cloud analysis (optional):** deploy `server/` anywhere that runs
   Docker (see `server/README.md`), then build the app with:
   ```
   flutter build apk --release --dart-define=ANALYSIS_SERVER_URL=https://your-server.example.com
   ```
   Without this, the app works fine in Offline mode only — no crash, no nag.
3. **Chess.com sync:** nothing to set up. It's Chess.com's public,
   unauthenticated API — just enter a username in Settings.
4. **Lichess sync (optional):** Lichess requires *you* to register a free
   OAuth client id at https://lichess.org/api/app (takes ~2 minutes, needs
   your Lichess account — I can't do this step for you, it's tied to your
   account and a redirect URI you own). Use:
   - Redirect URI: `chesscoach://lichess-callback` (already wired into
     `AndroidManifest.xml`)
   - Then build with `--dart-define=LICHESS_CLIENT_ID=your-client-id`

   Skip this entirely if you only care about Chess.com + PGN import for now.

## GitHub Secrets

**None are required.** Stockfish needs no API key (local or cloud). The
`--dart-define` values above are build-time flags, not secrets — they're
public URLs/client IDs, not credentials. If you deploy the server somewhere
that needs a deploy token (Fly.io, Render, etc.), that's specific to your
chosen host and isn't part of this repo's required setup.

## Repo layout

```
chess_coach/
├── .github/workflows/
│   ├── android.yml       # flutter pub get → analyze → test → build apk → upload artifact
│   └── server.yml        # npm test (real Stockfish) → docker build → smoke test
├── android/               # Android platform project
├── lib/
│   ├── models/            # ChessGame, MoveAnalysis, Evaluation
│   ├── services/          # PGN parsing, Stockfish (local+cloud), DB, Chess.com/Lichess, settings
│   ├── screens/           # Home, Games, Analysis, Training, Statistics, Settings
│   ├── widgets/            # Chessboard, evaluation graph
│   └── theme/              # Original board color themes
├── test/                   # Flutter unit tests
├── server/
│   ├── src/                 # Express app, Stockfish process pool, UCI parsing
│   ├── test/                 # Real tests incl. live-Stockfish integration suite
│   ├── Dockerfile
│   ├── docker-compose.yml
│   └── README.md            # Full server docs + verified test output
├── pubspec.yaml
└── .gitignore
```

## What's implemented vs. still ahead

**Implemented:** chessboard (original design), PGN import, local + cloud
Stockfish with Auto/Cloud/Offline switching, move-by-move analysis with
context-aware classification (Brilliant/Best/.../Blunder), evaluation
graph, Game Viewer, Games Library (filter/search/sort), Chess.com sync
(public API), Lichess OAuth (PKCE, no password ever stored), local SQLite
persistence, Statistics dashboard, Mistake/Blunder trainers pulled from
your own analyzed games, Settings (engine depth, MultiPV, board theme,
analysis mode).

**Still ahead** (the original spec is large — this is the honest remainder,
not a hidden gap): Game Review write-ups ("your opening was solid but..."),
opening-database "left theory at move N" detection, deeper pattern
detection for Learn From My Mistakes (hanging pieces, back-rank, king
safety — currently tagged at the blunder/mistake/missed-win level, not yet
broken into these finer categories), Opening/Endgame/Tactics/Critical-Moment
trainers beyond Mistake/Blunder, Smart Coach Q&A chat, rating progression
charts, analysis queue UI for bulk "analyze all games", request cancellation
mid-analysis on the Android side, and Docker deployment docs for a specific
host (kept generic since you haven't named one).

None of these are stubbed with fake data — they're just not built yet. I'd
rather hand you a smaller set of things that actually work than a larger
set where half silently does nothing.

## Building the APK

Push this to GitHub → **Actions** tab → wait for `Android` workflow → download
`chess-coach-apk` artifact from the run. Or locally: `flutter pub get &&
flutter build apk --release` (needs Flutter SDK + Android SDK).

## Running the server

See `server/README.md` — includes the exact commands I ran and their output.

