const { parseInfoLine, sideToMoveFromFen, normalizeToWhite } = require('../src/uciEngine');

describe('parseInfoLine', () => {
  test('parses a standard centipawn info line', () => {
    const line = 'info depth 18 seldepth 24 multipv 1 score cp 34 nodes 100000 pv e2e4 e7e5';
    const parsed = parseInfoLine(line);
    expect(parsed).toEqual({ depth: 18, cpFromMover: 34, mateFromMover: null, pv: ['e2e4', 'e7e5'] });
  });

  test('parses a mate score info line', () => {
    const line = 'info depth 10 multipv 1 score mate 3 pv d1h5 g8f6 h5f7';
    const parsed = parseInfoLine(line);
    expect(parsed.mateFromMover).toBe(3);
    expect(parsed.cpFromMover).toBeNull();
  });

  test('parses a negative centipawn score', () => {
    const line = 'info depth 12 multipv 1 score cp -120 pv g1f3';
    const parsed = parseInfoLine(line);
    expect(parsed.cpFromMover).toBe(-120);
  });

  test('returns null for a line with no score', () => {
    const line = 'info string NNUE evaluation enabled';
    expect(parseInfoLine(line)).toBeNull();
  });
});

describe('sideToMoveFromFen', () => {
  test('detects white to move', () => {
    expect(sideToMoveFromFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1')).toBe('w');
  });

  test('detects black to move', () => {
    expect(sideToMoveFromFen('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1')).toBe('b');
  });
});

describe('normalizeToWhite', () => {
  const whiteToMoveFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const blackToMoveFen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1';

  test('white-to-move positive score stays positive (good for White)', () => {
    const result = normalizeToWhite(whiteToMoveFen, 50, null);
    expect(result.evaluation).toBeCloseTo(0.5);
    expect(result.mate).toBeNull();
  });

  test('black-to-move positive score (good for Black, mover) flips to negative for White', () => {
    const result = normalizeToWhite(blackToMoveFen, 50, null);
    expect(result.evaluation).toBeCloseTo(-0.5);
  });

  test('black-to-move mate-for-mover becomes negative mate (Black delivers mate) from White perspective', () => {
    const result = normalizeToWhite(blackToMoveFen, null, 2);
    expect(result.mate).toBe(-2);
  });

  test('white-to-move mate-for-mover stays positive from White perspective', () => {
    const result = normalizeToWhite(whiteToMoveFen, null, 4);
    expect(result.mate).toBe(4);
  });

  test('null cp and null mate both pass through as null', () => {
    const result = normalizeToWhite(whiteToMoveFen, null, null);
    expect(result.evaluation).toBeNull();
    expect(result.mate).toBeNull();
  });
});
