const request = require('supertest');
const { createApp, validateAnalyzeBody, FEN_PATTERN } = require('../src/app');

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

const fakePool = {
  analyze: jest.fn().mockResolvedValue({
    evaluation: 0.25,
    mate: null,
    bestMove: 'e2e4',
    depth: 14,
    principalVariation: ['e2e4', 'e7e5'],
    multipv: [{ pv: ['e2e4', 'e7e5'], evaluation: 0.25, mate: null }],
  }),
};

describe('GET /api/health', () => {
  test('returns status ok', async () => {
    const app = createApp(fakePool);
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
  });
});

describe('POST /api/analyze validation', () => {
  test('rejects missing fen', async () => {
    const app = createApp(fakePool);
    const res = await request(app).post('/api/analyze').send({ depth: 10 });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/fen/i);
  });

  test('rejects malformed fen', async () => {
    const app = createApp(fakePool);
    const res = await request(app).post('/api/analyze').send({ fen: 'not-a-fen' });
    expect(res.status).toBe(400);
  });

  test('accepts a valid fen and returns normalized fields', async () => {
    const app = createApp(fakePool);
    const res = await request(app).post('/api/analyze').send({ fen: START_FEN, depth: 12 });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('evaluation');
    expect(res.body).toHaveProperty('bestMove', 'e2e4');
    expect(res.body).toHaveProperty('principalVariation');
  });

  test('clamps depth above the configured maximum instead of erroring', () => {
    const { depth, errors } = validateAnalyzeBody({ fen: START_FEN, depth: 999 });
    expect(errors).toHaveLength(0);
    expect(depth).toBeLessThanOrEqual(20);
  });

  test('clamps multipv above the configured maximum instead of erroring', () => {
    const { multipv, errors } = validateAnalyzeBody({ fen: START_FEN, multipv: 50 });
    expect(errors).toHaveLength(0);
    expect(multipv).toBeLessThanOrEqual(5);
  });

  test('defaults depth and multipv when omitted', () => {
    const { depth, multipv, errors } = validateAnalyzeBody({ fen: START_FEN });
    expect(errors).toHaveLength(0);
    expect(depth).toBeGreaterThan(0);
    expect(multipv).toBe(1);
  });
});

describe('FEN_PATTERN', () => {
  test('accepts the standard start position', () => {
    expect(FEN_PATTERN.test(START_FEN)).toBe(true);
  });

  test('rejects an empty string', () => {
    expect(FEN_PATTERN.test('')).toBe(false);
  });

  test('rejects a fen missing fields', () => {
    expect(FEN_PATTERN.test('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq')).toBe(false);
  });
});
