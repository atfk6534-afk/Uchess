const { EnginePool } = require('../src/enginePool');
const { createApp } = require('../src/app');
const request = require('supertest');

// This test spawns a real Stockfish process. It's skipped automatically if
// the binary isn't present at STOCKFISH_PATH (e.g. a minimal CI runner
// without it installed) so the rest of the suite still runs cleanly.
const fs = require('fs');
const config = require('../src/config');
const stockfishAvailable = fs.existsSync(config.stockfishPath);

const describeIfAvailable = stockfishAvailable ? describe : describe.skip;

describeIfAvailable('Real Stockfish integration', () => {
  let pool;
  let app;

  beforeAll(async () => {
    pool = new EnginePool(1);
    await pool.start();
    app = createApp(pool);
  }, 20000);

  afterAll(async () => {
    await pool.stop();
  });

  test('a real midgame-ish position returns a consistent, well-formed result', async () => {
    const fen = 'rnbqkbnr/pppp1ppp/8/4p3/5PPP/8/PPPPP3/RNBQKBNR b KQkq - 0 2';
    // Simplified: just confirm the engine returns a sane, consistent shape
    // for a real midgame-ish position rather than asserting an exact mate,
    // since exact tactics depend on engine version/search settings.
    const res = await request(app).post('/api/analyze').send({ fen, depth: 12 });
    expect(res.status).toBe(200);
    expect(typeof res.body.bestMove).toBe('string');
    expect(res.body.bestMove.length).toBeGreaterThanOrEqual(4);
    expect(res.body.depth).toBeGreaterThan(0);
    expect(Array.isArray(res.body.principalVariation)).toBe(true);
  });

  test('start position evaluates close to equal (within +/- 1.0 pawns)', async () => {
    const fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    const res = await request(app).post('/api/analyze').send({ fen, depth: 12 });
    expect(res.status).toBe(200);
    expect(res.body.evaluation).not.toBeNull();
    expect(Math.abs(res.body.evaluation)).toBeLessThan(1.0);
  });

  test('a position where White is up a whole queen shows a large evaluation for White', async () => {
    // Black queen removed entirely — White to move, up a full queen.
    const fen = 'rnb1kbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    const res = await request(app).post('/api/analyze').send({ fen, depth: 10 });
    expect(res.status).toBe(200);
    if (res.body.mate === null) {
      expect(res.body.evaluation).toBeGreaterThan(4);
    }
  }, 15000);

  test('health check works alongside a live engine pool', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
