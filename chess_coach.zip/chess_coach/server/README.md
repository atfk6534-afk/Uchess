# Chess Coach — Analysis Server

Cloud Stockfish analysis API. Node.js + Express, real Stockfish 16 process
pool with a request queue (never shares one engine's stdin across
concurrent requests), crash recovery, and hard limits on depth/time so a
bad request can't peg the server forever.

## Verified — this was actually run, not just written

I have a Node sandbox but no Flutter/Android SDK, so unlike the Android
side, **this server was genuinely installed, run, and tested** in this
session:

```
npm install          → 359 packages installed, 0 vulnerabilities
npx jest              → 25/25 tests passed (3 suites)
```

That includes an integration suite (`test/integration.test.js`) that spawns
the *real* `/usr/games/stockfish` binary (Stockfish 16, apt-installed) and
checks: health check, start-position eval near 0, a position where White is
up a full queen scores heavily positive, and a well-formed multi-field
response shape.

I also booted the server for real and hit it with `curl`:

```
GET  /api/health                  → {"status":"ok"}
POST /api/analyze {start pos}     → {"evaluation":0.4,"bestMove":"e2e4",...}
POST /api/analyze {"fen":"garbage"} → 400 {"error":"\"fen\" does not look like a valid FEN string."}
POST /api/analyze {}              → 400 {"error":"\"fen\" is required..."}
```

## Endpoints

### `GET /api/health`
```json
{ "status": "ok" }
```

### `POST /api/analyze`
Request:
```json
{ "fen": "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", "depth": 18, "multipv": 1 }
```
Response (evaluation always from **White's** perspective, regardless of
whose turn it is in the FEN):
```json
{
  "evaluation": 0.4,
  "mate": null,
  "bestMove": "e2e4",
  "depth": 18,
  "principalVariation": ["e2e4", "e7e5", "..."],
  "multipv": [{ "pv": ["e2e4", "e7e5"], "evaluation": 0.4, "mate": null }]
}
```
`depth` and `multipv` are optional and get clamped to server-configured
maximums rather than rejected. Invalid/missing `fen` returns `400`.

## Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `8080` | HTTP port |
| `STOCKFISH_PATH` | `/usr/games/stockfish` | Path to the Stockfish binary inside the container |
| `MAX_DEPTH` | `20` | Hard ceiling on requested search depth |
| `MAX_MULTIPV` | `5` | Hard ceiling on requested MultiPV lines |
| `MAX_ANALYSIS_TIME_MS` | `15000` | Hard ceiling on a single analysis, even if depth isn't reached |
| `STOCKFISH_POOL_SIZE` | `2` | Concurrent warm Stockfish processes |
| `STOCKFISH_THREADS` | `1` | Threads per Stockfish process |
| `STOCKFISH_HASH_MB` | `64` | Hash table size per process |
| `RATE_LIMIT_WINDOW_MS` | `60000` | Rate limit window |
| `RATE_LIMIT_MAX` | `30` | Max requests per window per IP |
| `ALLOWED_ORIGINS` | `*` | Comma-separated CORS allow-list |

None of these require a secret or API key — Stockfish itself needs none.

## Running locally

```
npm install
npm test              # runs the full suite, including real-engine integration tests
npm start              # or: STOCKFISH_PATH=/path/to/stockfish npm start
```

## Docker

```
docker build -t chess-coach-server .
docker run -p 8080:8080 chess-coach-server
```
or
```
docker compose up -d
```

I could not run `docker build` in this sandbox (no Docker daemon available
here), so the image build itself is untested by me — the `server.yml`
GitHub Actions workflow builds it on every push and will surface any issue.
The Dockerfile installs Stockfish from Debian's `apt` repo (same package/
version — 16 — the tests above were run against), so the main risk is low,
but treat the first CI run as the real verification.

## Deploying

This is a plain stateless HTTP container — it runs on any container host:
Render, Fly.io, Railway, a DigitalOcean/AWS/GCP VM with Docker, etc. Steps
are the same everywhere:

1. Push this repo (or just the `server/` folder) to your host of choice.
2. Point it at the `Dockerfile` here.
3. Set env vars if you want non-default limits (all optional).
4. Expose port `8080` (or set `PORT` to whatever the host expects).
5. Point the Android app's server URL setting at `https://your-host/api`.

No GitHub Secrets are required for the server itself — there's nothing to
authenticate against. If you later add your own auth in front of it, that's
a `SERVER_API_KEY`-style secret you'd add and check for yourself; it isn't
part of this build.
