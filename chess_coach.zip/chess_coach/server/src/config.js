// All limits below exist specifically so a malicious or buggy client can't
// make the server spin forever or spawn unbounded engine processes.
const config = {
  port: parseInt(process.env.PORT || '8080', 10),

  // Path to the Stockfish binary inside the container. Overridable so the
  // same image works whether Stockfish was apt-installed or copied in.
  stockfishPath: process.env.STOCKFISH_PATH || '/usr/games/stockfish',

  // Hard ceilings — requests asking for more get clamped down, never rejected
  // outright, so a slightly-too-eager client still gets a useful response.
  maxDepth: parseInt(process.env.MAX_DEPTH || '20', 10),
  maxMultiPv: parseInt(process.env.MAX_MULTIPV || '5', 10),
  maxAnalysisTimeMs: parseInt(process.env.MAX_ANALYSIS_TIME_MS || '15000', 10),

  // Number of concurrent Stockfish processes kept warm in the pool. Requests
  // beyond this queue up rather than spawning unbounded processes.
  poolSize: parseInt(process.env.STOCKFISH_POOL_SIZE || '2', 10),
  engineThreads: parseInt(process.env.STOCKFISH_THREADS || '1', 10),
  engineHashMb: parseInt(process.env.STOCKFISH_HASH_MB || '64', 10),

  rateLimitWindowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10),
  rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX || '30', 10),

  // Comma-separated list of allowed CORS origins. "*" by default so the
  // Android app (which has no browser origin) always works; tighten this
  // via the ALLOWED_ORIGINS env var if you add a web client.
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim()),
};

module.exports = config;
