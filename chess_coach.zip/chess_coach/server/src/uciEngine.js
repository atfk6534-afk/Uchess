const { spawn } = require('child_process');
const readline = require('readline');
const config = require('./config');

/**
 * Parses a UCI "info ... score cp X | mate Y ... pv ..." line.
 * Returns { depth, cpFromMover, mateFromMover, pv } or null if unparsable.
 * Values are from the perspective of the side to move (UCI convention) —
 * normalization to White's perspective happens in analyzeFen, since that
 * requires knowing whose turn it was in the FEN.
 */
function parseInfoLine(line) {
  const tokens = line.split(' ');
  let depth = null;
  let cp = null;
  let mate = null;
  let pv = [];

  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i] === 'depth') depth = parseInt(tokens[i + 1], 10);
    else if (tokens[i] === 'cp') cp = parseInt(tokens[i + 1], 10);
    else if (tokens[i] === 'mate') mate = parseInt(tokens[i + 1], 10);
    else if (tokens[i] === 'pv') {
      pv = tokens.slice(i + 1);
      break;
    }
  }

  if (depth === null || (cp === null && mate === null)) return null;
  return { depth, cpFromMover: cp, mateFromMover: mate, pv };
}

/** Extracts "w" or "b" (side to move) from a FEN string. Defaults to "w". */
function sideToMoveFromFen(fen) {
  const parts = fen.trim().split(/\s+/);
  return parts[1] === 'b' ? 'b' : 'w';
}

/**
 * Converts a mover-perspective score into White's perspective, which is the
 * contract this whole API guarantees to clients regardless of whose turn
 * it was in the position they sent.
 */
function normalizeToWhite(fen, cpFromMover, mateFromMover) {
  const stm = sideToMoveFromFen(fen);
  const sign = stm === 'w' ? 1 : -1;
  return {
    evaluation: cpFromMover === null ? null : (cpFromMover * sign) / 100,
    mate: mateFromMover === null ? null : mateFromMover * sign,
  };
}

class EngineCrashedError extends Error {
  constructor(message) {
    super(message);
    this.name = 'EngineCrashedError';
  }
}

class EngineTimeoutError extends Error {
  constructor(message) {
    super(message);
    this.name = 'EngineTimeoutError';
  }
}

/**
 * One long-lived Stockfish process. Only ever handles one `go` at a time —
 * concurrency across many simultaneous requests is handled by EnginePool
 * queueing work across several of these, never by sharing one process's
 * stdin between overlapping searches (which would corrupt engine state).
 */
class StockfishProcess {
  constructor() {
    this.proc = null;
    this.rl = null;
    this.busy = false;
    this.alive = false;
  }

  async start() {
    this.proc = spawn(config.stockfishPath, [], { stdio: ['pipe', 'pipe', 'pipe'] });
    this.alive = true;

    this.proc.on('exit', () => {
      this.alive = false;
    });
    this.proc.on('error', () => {
      this.alive = false;
    });

    this.rl = readline.createInterface({ input: this.proc.stdout });

    await this._waitFor('uciok', () => this._write('uci'));
    this._write(`setoption name Threads value ${config.engineThreads}`);
    this._write(`setoption name Hash value ${config.engineHashMb}`);
    await this._waitFor('readyok', () => this._write('isready'));
  }

  _write(cmd) {
    if (!this.alive || !this.proc.stdin.writable) {
      throw new EngineCrashedError('Stockfish process is not writable.');
    }
    this.proc.stdin.write(cmd + '\n');
  }

  _waitFor(token, trigger) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        reject(new EngineTimeoutError(`Timed out waiting for "${token}" from Stockfish.`));
      }, 10000);

      const onLine = (line) => {
        if (line.includes(token)) {
          cleanup();
          resolve();
        }
      };
      const cleanup = () => {
        clearTimeout(timeout);
        this.rl.off('line', onLine);
      };

      this.rl.on('line', onLine);
      trigger();
    });
  }

  /**
   * Runs a full analysis on a FEN and resolves with the normalized result.
   * Never lets a stuck engine hang the caller forever — enforces
   * config.maxAnalysisTimeMs as a hard ceiling on top of the depth limit.
   */
  async analyzeFen(fen, { depth, multipv }) {
    if (this.busy) {
      throw new Error('EnginePool bug: analyzeFen called on a busy process.');
    }
    if (!this.alive) {
      throw new EngineCrashedError('Stockfish process is not alive.');
    }
    this.busy = true;

    try {
      this._write(`setoption name MultiPV value ${multipv}`);
      this._write('ucinewgame');
      this._write(`position fen ${fen}`);

      const linesByPv = new Map(); // multipv index -> latest info
      let bestMoveUci = null;
      let reachedDepth = 0;

      await new Promise((resolve, reject) => {
        const hardTimeout = setTimeout(() => {
          cleanup();
          this._write('stop');
          reject(new EngineTimeoutError('Analysis exceeded the maximum allotted time.'));
        }, config.maxAnalysisTimeMs);

        const onLine = (line) => {
          if (line.startsWith('info') && line.includes('score')) {
            const parsed = parseInfoLine(line);
            if (parsed) {
              const pvIndexMatch = line.match(/multipv (\d+)/);
              const pvIndex = pvIndexMatch ? parseInt(pvIndexMatch[1], 10) : 1;
              linesByPv.set(pvIndex, parsed);
              reachedDepth = Math.max(reachedDepth, parsed.depth);
            }
          } else if (line.startsWith('bestmove')) {
            const parts = line.split(' ');
            bestMoveUci = parts[1] || null;
            cleanup();
            resolve();
          }
        };
        const cleanup = () => {
          clearTimeout(hardTimeout);
          this.rl.off('line', onLine);
        };

        this.rl.on('line', onLine);
        this._write(`go depth ${depth}`);
      });

      const top = linesByPv.get(1);
      if (!top) {
        throw new Error('Stockfish returned no evaluation for this position.');
      }

      const normalized = normalizeToWhite(fen, top.cpFromMover, top.mateFromMover);

      const variations = Array.from(linesByPv.entries())
        .sort((a, b) => a[0] - b[0])
        .map(([, info]) => ({
          pv: info.pv,
          ...normalizeToWhite(fen, info.cpFromMover, info.mateFromMover),
        }));

      return {
        evaluation: normalized.evaluation,
        mate: normalized.mate,
        bestMove: bestMoveUci,
        depth: reachedDepth,
        principalVariation: top.pv || [],
        multipv: variations,
      };
    } finally {
      this.busy = false;
    }
  }

  stop() {
    try {
      if (this.alive) this._write('quit');
    } catch (_) {
      // already dead, nothing to do
    }
    if (this.proc && !this.proc.killed) {
      this.proc.kill('SIGKILL');
    }
    this.alive = false;
  }
}

module.exports = {
  StockfishProcess,
  parseInfoLine,
  sideToMoveFromFen,
  normalizeToWhite,
  EngineCrashedError,
  EngineTimeoutError,
};
