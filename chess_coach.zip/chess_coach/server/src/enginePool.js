const { StockfishProcess, EngineCrashedError } = require('./uciEngine');
const config = require('./config');

/**
 * Owns N Stockfish processes. Requests beyond N queue up (FIFO) instead of
 * spawning unbounded processes — this is the mechanism that prevents
 * concurrent requests from corrupting a single engine's UCI state, and
 * caps how much CPU the server can ever commit to Stockfish at once.
 */
class EnginePool {
  constructor(size = config.poolSize) {
    this.size = size;
    this.processes = [];
    this.queue = []; // { fen, options, resolve, reject }
  }

  async start() {
    for (let i = 0; i < this.size; i++) {
      const proc = new StockfishProcess();
      await proc.start();
      this.processes.push(proc);
    }
  }

  async stop() {
    await Promise.all(this.processes.map((p) => p.stop()));
  }

  /** Public entry point: queues the request and returns a Promise. */
  analyze(fen, options) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fen, options, resolve, reject });
      this._drain();
    });
  }

  _drain() {
    if (this.queue.length === 0) return;
    const freeProcess = this.processes.find((p) => p.alive && !p.busy);
    if (!freeProcess) return; // all busy — next _drain() call (on completion) will pick it up

    const job = this.queue.shift();
    freeProcess
      .analyzeFen(job.fen, job.options)
      .then((result) => job.resolve(result))
      .catch(async (err) => {
        if (err instanceof EngineCrashedError) {
          await this._respawn(freeProcess);
        }
        job.reject(err);
      })
      .finally(() => this._drain());

    // More free processes might still be available for the next queued job.
    this._drain();
  }

  async _respawn(deadProcess) {
    deadProcess.stop();
    const idx = this.processes.indexOf(deadProcess);
    try {
      const fresh = new StockfishProcess();
      await fresh.start();
      if (idx >= 0) this.processes[idx] = fresh;
    } catch (_) {
      // Leave the slot empty; it just means reduced capacity until the
      // next request happens to trigger a successful respawn attempt.
      if (idx >= 0) this.processes.splice(idx, 1);
    }
  }
}

module.exports = { EnginePool };
