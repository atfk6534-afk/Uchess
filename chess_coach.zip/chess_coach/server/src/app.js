const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const config = require('./config');

// Loose but real FEN shape check: 6 space-separated fields, first field is
// 8 ranks separated by "/". Not a full legality check (that's the engine's
// job) — this just rejects garbage before it reaches Stockfish's stdin.
const FEN_PATTERN = /^([pnbrqkPNBRQK1-8]+\/){7}[pnbrqkPNBRQK1-8]+ [wb] ((K?Q?k?q?)|-) (-|[a-h][36]) \d+ \d+$/;

function validateAnalyzeBody(body) {
  const errors = [];
  if (!body || typeof body.fen !== 'string' || body.fen.trim() === '') {
    errors.push('"fen" is required and must be a non-empty string.');
  } else if (!FEN_PATTERN.test(body.fen.trim())) {
    errors.push('"fen" does not look like a valid FEN string.');
  }

  let depth = parseInt(body.depth, 10);
  if (Number.isNaN(depth) || depth < 1) depth = 14;
  depth = Math.min(depth, config.maxDepth);

  let multipv = parseInt(body.multipv, 10);
  if (Number.isNaN(multipv) || multipv < 1) multipv = 1;
  multipv = Math.min(multipv, config.maxMultiPv);

  return { errors, depth, multipv, fen: body && body.fen ? body.fen.trim() : null };
}

/**
 * Builds the Express app. Takes the engine pool as a parameter (rather than
 * importing a singleton) so tests can inject a fake/lightweight pool.
 */
function createApp(enginePool) {
  const app = express();

  app.use(helmet());
  app.use(
    cors({
      origin: config.allowedOrigins.includes('*') ? '*' : config.allowedOrigins,
    })
  );
  app.use(express.json({ limit: '32kb' })); // FEN + small params only, never a big payload

  const limiter = rateLimit({
    windowMs: config.rateLimitWindowMs,
    max: config.rateLimitMax,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests. Please slow down.' },
  });
  app.use('/api/', limiter);

  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  app.post('/api/analyze', async (req, res) => {
    const { errors, depth, multipv, fen } = validateAnalyzeBody(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ error: errors.join(' ') });
    }

    try {
      const result = await enginePool.analyze(fen, { depth, multipv });
      res.json({
        evaluation: result.evaluation,
        mate: result.mate,
        bestMove: result.bestMove,
        depth: result.depth,
        principalVariation: result.principalVariation,
        multipv: result.multipv,
      });
    } catch (err) {
      const isTimeout = err && err.name === 'EngineTimeoutError';
      res.status(isTimeout ? 504 : 500).json({
        error: isTimeout
          ? 'Analysis timed out. Try a lower depth.'
          : 'Analysis failed. The engine may have restarted — please retry.',
      });
    }
  });

  // Catch-all 404 for anything else under /api
  app.use('/api', (req, res) => {
    res.status(404).json({ error: 'Not found.' });
  });

  return app;
}

module.exports = { createApp, validateAnalyzeBody, FEN_PATTERN };
