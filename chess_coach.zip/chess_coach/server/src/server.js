const { createApp } = require('./app');
const { EnginePool } = require('./enginePool');
const config = require('./config');

async function main() {
  const pool = new EnginePool(config.poolSize);
  console.log(`Starting ${config.poolSize} Stockfish process(es) from ${config.stockfishPath}...`);
  await pool.start();
  console.log('Stockfish pool ready.');

  const app = createApp(pool);
  const server = app.listen(config.port, () => {
    console.log(`Chess Coach analysis API listening on port ${config.port}`);
  });

  const shutdown = async (signal) => {
    console.log(`Received ${signal}, shutting down...`);
    server.close();
    await pool.stop();
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
